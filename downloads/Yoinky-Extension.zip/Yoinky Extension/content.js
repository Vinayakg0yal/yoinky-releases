// Yoinky: a small "Download" button on videos, and the description of the
// last right-clicked image (used to give the downloaded file a good name).
(() => {
  // After an extension update, the extension puts a fresh copy of this script
  // into pages that were already open. The fresh copy takes over from the old
  // one (which can't reach the extension anymore), so pages never need a reload.
  // (The event name has the extension's id in it, so a web page can't send it.)
  const TAKEOVER = `yoinky-takeover-${chrome.runtime.id}`;
  document.dispatchEvent(new CustomEvent(TAKEOVER));
  // Copies from versions before 1.6 listen for the old name.
  document.dispatchEvent(new CustomEvent("yoinky-takeover"));
  let stopped = false;
  let lastToast = null;
  function stopHere() {
    if (stopped) return;
    stopped = true;
    try {
      hide();
      pill.remove();
    } catch {}
  }
  document.addEventListener(TAKEOVER, stopHere, { once: true });
  /** This copy can still talk to the extension. */
  const alive = () => {
    if (stopped) return false;
    if (chrome.runtime?.id) return true;
    stopHere(); // the extension was updated and this page wasn't given a fresh copy
    return false;
  };

  // ---- Image descriptions for the right-click menu
  let lastDescription = "";
  // On Google Images, the thumbnail sits inside a result link that carries the
  // original's address; sending that gets the full-size picture.
  let lastResultLink = "";
  document.addEventListener(
    "contextmenu",
    (e) => {
      if (stopped) return;
      const img = e.target instanceof Element ? e.target.closest("img") : null;
      lastDescription = img ? (img.getAttribute("alt") || img.getAttribute("title") || "").trim() : "";
      lastResultLink = "";
      const link = img?.closest("a[href]");
      const href = link?.getAttribute("href") || "";
      if (href && /\/imgres\?|[?&]imgurl=|[?&]imgrc=/.test(href)) {
        try {
          lastResultLink = new URL(href, location.href).href;
        } catch {}
      } else if (/(^|\.)google\./.test(location.hostname) && img) {
        // Opened big (the side panel): the big image is the original itself,
        // unless it's still a gstatic preview.
        const src = img.currentSrc || img.src || "";
        if (/^https?:/.test(src) && !/gstatic\.com/.test(src)) lastResultLink = src;
      }
    },
    true,
  );
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (stopped) return;
    if (msg?.type === "yoinky-last-description") reply({ description: lastDescription, resultLink: lastResultLink });
    // "Opening Yoinky…" and the like, from the extension.
    if (msg?.type === "yoinky-toast" && msg.text) toast(msg.text, !!msg.isError);
    // The right-click menu on Instagram: read the post/story here.
    if (msg?.type === "yoinky-instagram") {
      instagramData(msg.url).then((data) => reply({ data }));
      return true;
    }
  });

  const onInstagram = /(^|\.)instagram\.com$/.test(location.hostname);
  const onX = /(^|\.)(x|twitter)\.com$/.test(location.hostname);

  // ---- Instagram, read the way instagram.com itself reads it: from this
  // page, with the browser's own sign-in. Yoinky gets the photo and video
  // addresses and downloads them; nothing else leaves the browser.
  const IG_APP_ID = "936619743392459";
  const IG_CODE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

  function igPk(code) {
    const c = code.length > 28 ? code.slice(0, -28) : code;
    let n = 0n;
    for (const ch of c) {
      const d = IG_CODE.indexOf(ch);
      if (d < 0) return null;
      n = n * 64n + BigInt(d);
    }
    return n > 0n ? n.toString() : null;
  }

  async function igApi(path) {
    const csrf = (document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/) || [])[1] || "";
    let claim = "0";
    try {
      claim = sessionStorage.getItem("www-claim-v2") || "0";
    } catch {}
    const res = await fetch(path, {
      credentials: "include",
      headers: {
        Accept: "*/*",
        "X-IG-App-ID": IG_APP_ID,
        "X-ASBD-ID": "359341",
        "X-CSRFToken": csrf,
        "X-IG-WWW-Claim": claim,
        "X-Requested-With": "XMLHttpRequest",
      },
    });
    if (!res.ok) throw new Error(`Instagram ${res.status}`);
    return res.json();
  }

  /** Just the parts Yoinky needs: the photo/video addresses and sizes. */
  const slim = (m) => ({
    pk: String(m.pk ?? ""),
    media_type: m.media_type,
    video_duration: m.video_duration,
    video_versions: (m.video_versions || []).map((v) => ({ url: v.url, width: v.width, height: v.height })),
    image_versions2: {
      candidates: (m.image_versions2?.candidates || []).map((c) => ({ url: c.url, width: c.width, height: c.height })),
    },
  });

  /** An Instagram post or story's photos and videos, or null. */
  async function instagramData(link) {
    if (!onInstagram) return null;
    let u;
    try {
      u = new URL(link);
    } catch {
      return null;
    }
    if (!/(^|\.)instagram\.com$/.test(u.hostname)) return null;
    const segs = u.pathname.split("/").filter(Boolean);
    try {
      if (segs[0] === "stories" && segs[1]) {
        const highlight = segs[1] === "highlights";
        let reel;
        if (highlight) {
          if (!segs[2]) return null;
          reel = `highlight:${segs[2]}`;
        } else {
          const profile = await igApi(`/api/v1/users/web_profile_info/?username=${encodeURIComponent(segs[1])}`);
          reel = profile?.data?.user?.id;
          if (!reel) return null;
        }
        const data = await igApi(`/api/v1/feed/reels_media/?reel_ids=${encodeURIComponent(reel)}`);
        const r = data?.reels?.[reel] || data?.reels_media?.[0];
        if (!r?.items?.length) return null;
        return {
          kind: "story",
          user: r.user?.username || (highlight ? "" : segs[1]),
          title: r.title || "",
          items: r.items.map(slim),
        };
      }
      const i = segs.findIndex((s) => ["p", "reel", "reels", "tv"].includes(s));
      if (i < 0 || i > 1 || !segs[i + 1]) return null;
      const pk = igPk(segs[i + 1]);
      if (!pk) return null;
      const data = await igApi(`/api/v1/media/${pk}/info/`);
      const m = data?.items?.[0];
      if (!m) return null;
      return {
        kind: "post",
        user: m.user?.username || "",
        caption: m.caption?.text || "",
        items: (m.carousel_media?.length ? m.carousel_media : [m]).map(slim),
      };
    } catch {
      return null; // Yoinky will try on its own
    }
  }

  // ---- Video button
  // Not on copy-protected (DRM) streaming services: Yoinky can't download those.
  const DRM_HOSTS = /(^|\.)(netflix\.com|disneyplus\.com|primevideo\.com|hulu\.com|max\.com|hbomax\.com|tv\.apple\.com|peacocktv\.com|paramountplus\.com|crave\.ca|crunchyroll\.com|spotify\.com|music\.apple\.com|tidal\.com|deezer\.com)$/i;
  const isAmazonVideo = /(^|\.)amazon\./i.test(location.hostname) && /\/(gp\/)?video\//.test(location.pathname);
  if (DRM_HOSTS.test(location.hostname) || isAmazonVideo) return;

  // A small, see-through round button in the video's top-right corner. It
  // only shows while the pointer moves over a video, fades out when the
  // pointer rests, and turns Yoinky-blue when hovered.
  const pill = document.createElement("button");
  pill.className = "yoinky-pill";
  pill.type = "button";
  pill.setAttribute("aria-label", "Download with Yoinky");
  pill.title = "Download with Yoinky";
  pill.innerHTML =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>';
  const SIZE = 32;
  const INSET = 12;
  let current = null;
  let frame = 0;
  let idleTimer = 0;
  let hideTimer = 0;

  /** Instagram and X: the post the video belongs to (in a feed, the page
   *  address is the feed, not the post). Yoinky reads the post from there. */
  function postLink(video) {
    const host = location.hostname;
    const abs = (a) => new URL(a.getAttribute("href"), location.href).href;
    if (/(^|\.)instagram\.com$/.test(host)) {
      // A tile on a profile or Explore page links to its post.
      const own = video.closest('a[href*="/p/"], a[href*="/reel/"]');
      if (own) return abs(own);
      // Already on the post, reel or story.
      if (/^\/((stories|p|reels?|tv)\/|[^/]+\/(p|reel)\/)/.test(location.pathname)) return location.href;
      const box = video.closest("article") || video.closest("[role=dialog]");
      const link = box?.querySelector('a[href*="/p/"], a[href*="/reel/"]');
      return link ? abs(link) : location.href;
    }
    if (/(^|\.)(x|twitter)\.com$/.test(host)) {
      // A photo: its own link (…/status/123/photo/2) picks that photo.
      const photo = video.closest('a[href*="/photo/"]');
      if (photo) return abs(photo);
      const box = video.closest("article");
      const links = [...(box?.querySelectorAll('a[href*="/status/"]') || [])];
      // The post's own link is the one around its time stamp.
      const link = links.find((a) => a.querySelector("time")) || links[0];
      return link ? abs(link).replace(/\/(photo|video|analytics|history)(\/.*)?$/, "") : location.href;
    }
    return null;
  }

  function videoUrl(video) {
    const post = postLink(video);
    if (post) return post;
    const src = video.currentSrc || video.src || "";
    // Streamed videos (blob:, HLS, DASH) are downloaded from their page instead.
    if (/^https?:/i.test(src) && !/\.(m3u8|mpd)(\?|$)/i.test(src) && !/youtube\.com|googlevideo\.com/.test(src)) return src;
    return location.href;
  }

  /** Where the button lives: the page, or the full-screen player while full screen. */
  function host() {
    const fs = document.fullscreenElement;
    if (fs && fs.tagName !== "VIDEO") return fs;
    return document.documentElement;
  }

  // ---- Where the button goes: a spot on (or next to) the video where the
  // site has no button of its own, so it never covers the player's or the
  // site's controls (Instagram's "…", X's menus, YouTube's "Share").
  const SPOTS = [
    (r) => [r.right - SIZE - INSET, r.top + INSET], // top right
    (r) => [r.left + INSET, r.top + INSET], // top left
    (r) => [r.left + r.width / 2 - SIZE / 2, r.top + INSET], // top middle
    (r) => [r.right - SIZE - INSET, r.top + r.height / 2 - SIZE / 2], // right middle
    (r) => [r.left + INSET, r.top + r.height / 2 - SIZE / 2], // left middle
    (r) => [r.right - SIZE, r.top - SIZE - 6], // just above, right
    (r) => [r.right + 6, r.top], // just to the right
  ];
  let spot = 0;
  let spotCheckedAt = 0;

  const CLICKABLE =
    'a[href], button, input, select, textarea, label, summary, [role="button"], [role="link"], [role="menuitem"], [role="slider"], [role="checkbox"], [role="switch"], [role="tab"]';

  /** Is one of the site's own buttons at this point? */
  function siteControlAt(px, py, media, mediaArea) {
    const el = document.elementsFromPoint(px, py).find((e) => e !== pill && !pill.contains(e));
    if (!el || el === media || el.contains(media)) return false;
    // From what's under the point up to the box that holds the video.
    for (let n = el; n && n !== document.body && n !== document.documentElement && !n.contains(media); n = n.parentElement) {
      const b = n.getBoundingClientRect();
      if (b.width * b.height >= mediaArea * 0.6) continue; // an overlay over the whole video
      if (n.matches(CLICKABLE)) return true;
      if (getComputedStyle(n).cursor === "pointer") return true;
    }
    return false;
  }

  function spotIsFree(i, r) {
    const [x, y] = SPOTS[i](r);
    if (x < 4 || y < 4 || x + SIZE > window.innerWidth - 4 || y + SIZE > window.innerHeight - 4) return false;
    const area = r.width * r.height;
    const pad = 3;
    const points = [
      [x + SIZE / 2, y + SIZE / 2],
      [x + pad, y + pad],
      [x + SIZE - pad, y + pad],
      [x + pad, y + SIZE - pad],
      [x + SIZE - pad, y + SIZE - pad],
    ];
    return !points.some(([px, py]) => siteControlAt(px, py, current, area));
  }

  /** Pick the first free spot (checked now and then, not every frame). */
  function chooseSpot(r) {
    const free = SPOTS.findIndex((_, i) => spotIsFree(i, r));
    spot = free >= 0 ? free : -1;
    spotCheckedAt = performance.now();
  }

  /** Follow the video every frame while shown: no lag when the player resizes,
   *  goes full screen or scrolls. Uses transform only, so it's cheap and smooth.
   *  Stops while the button is faded out (the next pointer move restarts it). */
  function follow() {
    frame = 0;
    if (pill.classList.contains("idle")) return;
    if (!current || !current.isConnected) return hide();
    if (document.fullscreenElement && document.fullscreenElement.tagName === "VIDEO") return hide();
    if (pill.parentNode !== host()) host().appendChild(pill);
    const r = current.getBoundingClientRect();
    if (performance.now() - spotCheckedAt > 400) chooseSpot(r);
    // Nowhere free (rare): stay out of the way rather than cover the site's buttons.
    pill.classList.toggle("nowhere", spot < 0);
    const [x, y] = SPOTS[Math.max(spot, 0)](r);
    pill.style.transform = `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
    frame = requestAnimationFrame(follow);
  }

  function show(video) {
    clearTimeout(hideTimer);
    if (current !== video) spotCheckedAt = 0; // new video: find its spot
    current = video;
    pill.classList.add("on");
    pill.classList.remove("idle");
    if (!frame) follow();
    // Fade away when the pointer rests, like the player's own controls.
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (pill.matches(":hover") || pill.classList.contains("busy")) return;
      pill.classList.add("idle");
    }, 2500);
  }

  function hide() {
    clearTimeout(idleTimer);
    pill.classList.remove("on");
    current = null;
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
  }

  function hideSoon() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, 400);
  }

  const bigEnough = (el) => {
    const r = el.getBoundingClientRect();
    return r.width >= 280 && r.height >= 150;
  };
  /** Instagram and X: photos too (Yoinky offers the whole post, or a story). */
  const isMedia = (el) =>
    el.tagName === "VIDEO" ||
    (el.tagName === "IMG" && (onInstagram || (onX && !!el.closest('a[href*="/photo/"]'))));

  function videoUnder(x, y) {
    // What's at the pointer, including what sits under the player's overlays
    // (and one level into players built as custom elements).
    const stack = document.elementsFromPoint(x, y);
    for (const el of stack) {
      if (el === pill) continue;
      if (isMedia(el)) {
        if (bigEnough(el)) return el;
        continue;
      }
      if (el.shadowRoot) {
        const inner = el.shadowRoot.elementsFromPoint(x, y).find((n) => n.tagName === "VIDEO" && bigEnough(n));
        if (inner) return inner;
      }
    }
    // Players that turn off pointer hits on the video itself.
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < 280 || r.height < 150) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return v;
    }
    return null;
  }

  // mousemove (not just mouseover), so it reappears when the pointer moves again.
  let lastMove = 0;
  document.addEventListener(
    "mousemove",
    (e) => {
      const now = performance.now();
      if (now - lastMove < 50) return; // plenty, and keeps it light
      lastMove = now;
      if (!e.isTrusted || !alive()) return;
      if (e.target === pill || pill.contains(e.target)) {
        clearTimeout(hideTimer);
        clearTimeout(idleTimer);
        pill.classList.remove("idle");
        if (!frame && current) follow();
        return;
      }
      const video = videoUnder(e.clientX, e.clientY);
      if (video) show(video);
      else if (current) hideSoon();
    },
    true,
  );
  document.addEventListener("mouseleave", () => !stopped && current && hideSoon());

  pill.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!e.isTrusted || !current || !alive()) return; // a real click only, not the page's script
    pill.classList.add("busy");
    let result;
    try {
      const url = videoUrl(current);
      // Instagram: read the post/story here, with this browser's sign-in.
      const instagram = await instagramData(url);
      result = await chrome.runtime.sendMessage({ type: "yoinky-send", url, source: "video", instagram });
    } catch {
      // Only if this page couldn't be given the updated extension.
      stopHere();
      result = { ok: false, error: "Yoinky's extension was just updated. Reload this page once to use it here." };
    }
    pill.classList.remove("busy");
    toast(result?.ok ? "Sent to Yoinky. Pick what to download there." : result?.error || "Couldn't reach Yoinky.", !result?.ok);
  });
  // Don't let the player treat the click as play/pause.
  for (const type of ["mousedown", "mouseup", "dblclick", "pointerdown", "pointerup"]) {
    pill.addEventListener(type, (e) => e.stopPropagation());
  }

  function toast(text, isError) {
    lastToast?.remove(); // one at a time ("Opening Yoinky…" → "Sent to Yoinky")
    const t = document.createElement("div");
    lastToast = t;
    t.className = `yoinky-toast${isError ? " error" : ""}`;
    t.textContent = text;
    host().appendChild(t);
    requestAnimationFrame(() => t.classList.add("on"));
    setTimeout(() => {
      t.classList.remove("on");
      setTimeout(() => t.remove(), 300);
    }, 3200);
  }
})();
