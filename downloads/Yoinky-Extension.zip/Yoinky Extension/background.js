// Yoinky browser extension: hands downloads, videos and images to the Yoinky
// app, which listens on this computer only (127.0.0.1).

const PORTS = [41783, 41784, 41785, 41786, 41787];
const DEFAULTS = { enabled: true, minSizeMB: 1 };

// ---------------------------------------------------------------- settings

async function settings() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

async function updateIcon() {
  const { enabled } = await settings();
  const set = enabled ? "icon" : "off";
  await chrome.action.setIcon({ path: { 16: `icons/${set}16.png`, 32: `icons/${set}32.png` } });
  await chrome.action.setTitle({ title: enabled ? "Yoinky: catching downloads" : "Yoinky: paused" });
}

// ---------------------------------------------------------------- the app

let app = null; // { port, info, at }

/** Find the running Yoinky app. Returns its /ping info, or null. */
async function findApp(force = false) {
  if (!force && app && Date.now() - app.at < 30_000) return app;
  const order = app ? [app.port, ...PORTS.filter((p) => p !== app.port)] : PORTS;
  for (const port of order) {
    try {
      // Our ID lets Yoinky register the helper that opens it when it's closed.
      const query = `v=${chrome.runtime.getManifest().version}&id=${chrome.runtime.id}`;
      const res = await fetch(`http://127.0.0.1:${port}/ping?${query}`, {
        headers: { "X-Yoinky": "1" },
        signal: AbortSignal.timeout(800),
      });
      if (!res.ok) continue;
      const info = await res.json();
      if (info.app !== "Yoinky") continue;
      app = { port, info, at: Date.now() };
      maybeSelfUpdate(info);
      return app;
    } catch {
      // Not on this port.
    }
  }
  app = null;
  return null;
}

// ---------------------------------------------------------------- opening Yoinky
// When Yoinky is closed, the browser can start a small helper that Yoinky
// registers for this extension ("native messaging"). It opens the app.

const HOST = "com.yoinky.desktop";
const NOT_SET_UP = "Open the Yoinky app once. After that, Yoinky opens by itself when you download.";

function askHelper(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(HOST, message, (reply) => {
        resolve(chrome.runtime.lastError ? { ok: false, missing: true } : reply || { ok: false });
      });
    } catch {
      resolve({ ok: false, missing: true });
    }
  });
}

/** Open Yoinky and wait until it's ready. Resolves to { app } or { error }. */
async function launchApp() {
  const reply = await askHelper({ type: "launch" });
  if (!reply.ok) return { error: reply.missing ? NOT_SET_UP : "Couldn't open Yoinky. Open it yourself and try again." };
  // It takes a few seconds to start.
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 500));
    chrome.runtime.getPlatformInfo().catch(() => {}); // keeps this worker awake while waiting
    const found = await findApp(true);
    if (found) return { app: found };
  }
  return { error: "Yoinky is taking a while to open. Try again in a moment." };
}

/**
 * Send something to Yoinky. Opens Yoinky first if it's closed (unless
 * `launch` is false). Resolves to { ok, error? }.
 */
async function sendToApp(payload, { launch = true, onLaunching } = {}) {
  let found = await findApp();
  for (let attempt = 0; attempt < 2; attempt++) {
    if (!found) {
      if (!launch) return { ok: false, error: "Yoinky isn't running." };
      onLaunching?.();
      const opened = await launchApp();
      if (!opened.app) return { ok: false, error: opened.error };
      found = opened.app;
    }
    try {
      const res = await fetch(`http://127.0.0.1:${found.port}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Yoinky": "1" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(4000),
      });
      if (!res.ok) return { ok: false, error: `Yoinky said no (${res.status}).` };
      return { ok: true };
    } catch {
      // It was closed a moment ago: look again (and open it if needed).
      app = null;
      found = await findApp(true);
    }
  }
  return { ok: false, error: "Couldn't reach Yoinky." };
}

/** Cookies for a link, so files behind a login download in Yoinky too. */
async function cookiesFor(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

async function payloadFor(url, extra = {}) {
  return {
    url,
    cookies: await cookiesFor(url),
    userAgent: navigator.userAgent,
    extensionVersion: chrome.runtime.getManifest().version,
    ...extra,
  };
}

// ---------------------------------------------------------------- updates

const newer = (a, b) => {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
};

/**
 * Yoinky keeps this extension's files up to date (it rewrites them when the
 * app updates). When the app reports a newer version, reload so the browser
 * picks up the new files. Once per version, so it can never loop.
 */
async function maybeSelfUpdate(info) {
  const current = chrome.runtime.getManifest().version;
  const behind = !!info.extensionVersion && newer(info.extensionVersion, current);
  // A small "↑" on the toolbar icon while a newer version is waiting.
  chrome.action.setBadgeBackgroundColor({ color: "#0a7aff" }).catch(() => {});
  chrome.action.setBadgeText({ text: behind ? "↑" : "" }).catch(() => {});
  if (!behind) return;
  const { reloadedFor } = await chrome.storage.local.get("reloadedFor");
  if (reloadedFor === info.extensionVersion) return;
  await chrome.storage.local.set({ reloadedFor: info.extensionVersion });
  chrome.runtime.reload();
}

// ---------------------------------------------------------------- catching downloads

/** Links we hand back to the browser (Yoinky closed, or it refused). */
const passThrough = new Set();

chrome.downloads.onCreated.addListener(async (item) => {
  const url = item.finalUrl || item.url;
  if (passThrough.has(url) || passThrough.has(item.url)) {
    passThrough.delete(url);
    passThrough.delete(item.url);
    return;
  }
  if (item.byExtensionId === chrome.runtime.id) return;
  if (!/^https?:/i.test(url)) return; // blob:, data: and file: stay in the browser
  if (item.mime === "text/html") return;

  const { enabled, minSizeMB } = await settings();
  if (!enabled) return;
  if (item.totalBytes > 0 && item.totalBytes < minSizeMB * 1024 * 1024) return;
  if (!(await findApp())) return; // Yoinky closed: the browser downloads it as usual

  // Take it over from the browser.
  try {
    await chrome.downloads.cancel(item.id);
  } catch {}
  chrome.downloads.erase({ id: item.id }).catch(() => {});

  const result = await sendToApp(
    await payloadFor(url, {
      referrer: item.referrer || "",
      fileName: (item.filename || "").split(/[\\/]/).pop() || "",
      size: item.totalBytes > 0 ? item.totalBytes : null,
      source: "download",
    }),
    { launch: false }, // a download the browser started itself: don't open Yoinky for it
  );
  if (!result.ok) {
    // Give it back to the browser.
    passThrough.add(url);
    chrome.downloads.download({ url }).catch(() => passThrough.delete(url));
  }
});

// ---------------------------------------------------------------- finding media on pages
// Like IDM: watch what each tab loads and remember the videos and audio it
// plays (direct files and HLS/DASH stream playlists), even inside embedded
// players. The video button and the popup then download exactly that.

const STREAM_URL = /\.(m3u8|mpd)(\?|#|$)/i;
const VIDEO_URL = /\.(mp4|m4v|webm|mov|mkv|flv|avi|3gp)(\?|#|$)/i;
const AUDIO_URL = /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|weba)(\?|#|$)/i;
// Pieces of a stream, not something to download on their own.
const SEGMENT_URL = /\.(ts|m4s|cmfv|cmfa|vtt|srt|key)(\?|#|$)|[/_.-](seg|segment|chunk|frag|fragment)[-_]?\d+|\/range\/\d/i;
// Handled by their own page link (yt-dlp knows these sites).
const SKIP_HOSTS = /(^|\.)(googlevideo\.com|youtube\.com|ytimg\.com|fbcdn\.net|cdninstagram\.com|twimg\.com|tiktokcdn\.com)$/i;

const headerOf = (headers, name) => (headers || []).find((h) => h.name.toLowerCase() === name)?.value || "";

function mediaKind(url, type) {
  const t = type.toLowerCase();
  if (t.includes("mpegurl") || t.includes("dash+xml") || STREAM_URL.test(url)) return "stream";
  if (SEGMENT_URL.test(url) || t === "video/mp2t" || t.includes("iso.segment")) return null;
  if (t.startsWith("video/") || VIDEO_URL.test(url)) return "video";
  if (t.startsWith("audio/") || AUDIO_URL.test(url)) return "audio";
  return null;
}

async function mediaFor(tabId) {
  const key = `media:${tabId}`;
  return (await chrome.storage.session.get(key))[key] || [];
}

async function setMediaFor(tabId, list) {
  await chrome.storage.session.set({ [`media:${tabId}`]: list });
  const text = list.length ? String(list.length) : "";
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#0a7aff" }).catch(() => {});
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || (d.statusCode && d.statusCode >= 400)) return;
    if (!/^https?:/i.test(d.url)) return;
    let host = "";
    try {
      host = new URL(d.url).hostname;
    } catch {
      return;
    }
    if (SKIP_HOSTS.test(host)) return;
    const type = headerOf(d.responseHeaders, "content-type");
    const kind = mediaKind(d.url, type);
    if (!kind) return;
    // Real size (a 206 reply's Content-Length is only one piece).
    const range = headerOf(d.responseHeaders, "content-range");
    const size = Number(range.split("/")[1]) || Number(headerOf(d.responseHeaders, "content-length")) || 0;
    if (kind === "video" && size && size < 512 * 1024) return; // previews, ads, thumbnails
    if (kind === "audio" && size && size < 200 * 1024) return; // clicks and blips
    (async () => {
      const list = await mediaFor(d.tabId);
      if (list.some((m) => m.url === d.url)) return;
      list.push({
        url: d.url,
        kind,
        size,
        type,
        // The page or embedded player that loaded it: sent as Referer/Origin.
        frameUrl: d.initiator && d.initiator !== "null" ? d.initiator : d.documentUrl || "",
        time: Date.now(),
      });
      await setMediaFor(d.tabId, list.slice(-20));
    })();
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other", "object"] },
  ["responseHeaders"],
);

// A new page in the tab: forget the old page's media.
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === "loading" && change.url) setMediaFor(tabId, []);
});
chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(`media:${tabId}`));

/** The best thing to download from a tab, preferring the frame the user clicked in. */
async function bestMedia(tabId, frameUrl) {
  const list = await mediaFor(tabId);
  if (!list.length) return null;
  let origin = "";
  try {
    origin = new URL(frameUrl).origin;
  } catch {}
  const rank = { stream: 3, video: 2, audio: 1 };
  const score = (m) => (origin && m.frameUrl.startsWith(origin) ? 10 : 0) + rank[m.kind];
  // Highest score; among equals, the first stream playlist (the "master" one
  // listing every quality) or the biggest file.
  return [...list].sort((a, b) => score(b) - score(a) || (a.kind === "stream" ? a.time - b.time : b.size - a.size))[0];
}

/** Send a found video/audio to Yoinky, with what its player would send. */
async function sendMedia(m, tab, options) {
  let origin = "";
  try {
    origin = new URL(m.frameUrl || tab?.url || "").origin;
  } catch {}
  return sendToApp(
    await payloadFor(m.url, {
      referrer: m.frameUrl ? (m.frameUrl.endsWith("/") ? m.frameUrl : m.frameUrl + "/") : tab?.url || "",
      origin,
      description: tab?.title || "",
      source: m.kind,
    }),
    options,
  );
}

// ---------------------------------------------------------------- right-click menu

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "yoinky-link", title: "Download link with Yoinky", contexts: ["link"] });
    chrome.contextMenus.create({ id: "yoinky-image", title: "Download full-size image with Yoinky", contexts: ["image"] });
    chrome.contextMenus.create({ id: "yoinky-video", title: "Download video with Yoinky", contexts: ["video", "audio"] });
    chrome.contextMenus.create({ id: "yoinky-page", title: "Download this page's video with Yoinky", contexts: ["page"] });
  });
}

/** A short message on the page (from the content script). */
function toastIn(tabId, frameId, text, isError = false) {
  chrome.tabs.sendMessage(tabId, { type: "yoinky-toast", text, isError }, { frameId }).catch(() => {});
}

async function flashBadge(text, color) {
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 4000);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  let url = info.pageUrl;
  let source = "page";
  let description = "";
  if (info.menuItemId === "yoinky-link") {
    url = info.linkUrl;
    source = "link";
  } else if (info.menuItemId === "yoinky-image") {
    url = info.srcUrl;
    source = "image";
    // The page's description of the picture helps name the file.
    if (tab?.id != null) {
      try {
        const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-last-description" });
        description = reply?.description || "";
        // Google Images: the result link leads to the full-size original.
        if (reply?.resultLink) url = reply.resultLink;
      } catch {}
    }
  } else if (info.menuItemId === "yoinky-video") {
    // Streamed videos (blob:) can only be downloaded from their page.
    url = info.srcUrl && /^https?:/i.test(info.srcUrl) && !/\.m3u8|\.mpd/i.test(info.srcUrl) ? info.srcUrl : info.pageUrl;
    source = "video";
  }
  if (!url || !/^https?:/i.test(url)) {
    url = info.pageUrl;
    source = "page";
  }
  // Instagram: let the page read the post/story with the browser's sign-in.
  let instagram;
  if (tab?.id != null && /^https:\/\/([^/]+\.)?instagram\.com\//.test(tab.url || "") && /instagram\.com\//.test(url)) {
    try {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-instagram", url }, { frameId: 0 });
      instagram = reply?.data || undefined;
    } catch {}
  }
  const result = await sendToApp(await payloadFor(url, { referrer: info.pageUrl || "", description, source, instagram }), {
    onLaunching: () => tab?.id != null && toastIn(tab.id, info.frameId ?? 0, "Opening Yoinky…"),
  });
  flashBadge(result.ok ? "✓" : "!", result.ok ? "#22c55e" : "#ef4444");
  if (!result.ok && tab?.id != null) toastIn(tab.id, info.frameId ?? 0, result.error, true);
});

// ---------------------------------------------------------------- messages (popup, video button)

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === "yoinky-status") {
      const found = await findApp(true);
      const version = chrome.runtime.getManifest().version;
      const latest = found?.info.extensionVersion ?? null;
      reply({
        connected: !!found,
        appVersion: found?.info.version ?? null,
        version,
        latestVersion: latest,
        updateAvailable: !!latest && newer(latest, version),
        ...(await settings()),
      });
    } else if (msg.type === "yoinky-update") {
      // Load the new files Yoinky put in the extension folder.
      reply({ ok: true });
      setTimeout(() => chrome.runtime.reload(), 100);
    } else if (msg.type === "yoinky-settings") {
      await chrome.storage.local.set(msg.values);
      await updateIcon();
      reply({ ok: true });
    } else if (msg.type === "yoinky-send") {
      // The video button: download what this player actually plays, if seen.
      const tab = sender.tab;
      const options = {
        onLaunching: () => tab?.id != null && toastIn(tab.id, sender.frameId ?? 0, "Opening Yoinky…"),
      };
      const found = msg.source === "video" && tab?.id != null ? await bestMedia(tab.id, sender.url || "") : null;
      const pageIsKnownSite = /youtube\.com|youtu\.be|vimeo\.com|dailymotion|twitch\.tv|instagram|tiktok|facebook|x\.com|twitter|reddit/i.test(
        tab?.url || "",
      );
      if (found && !pageIsKnownSite) {
        reply(await sendMedia(found, tab, options));
      } else {
        const payload = await payloadFor(msg.url, {
          referrer: sender.url || tab?.url || "",
          description: tab?.title || "",
          source: msg.source || "video",
          // Instagram: the post/story as read in the page (with the browser's sign-in).
          instagram: msg.instagram || undefined,
        });
        reply(await sendToApp(payload, options));
      }
    } else if (msg.type === "yoinky-media") {
      // The popup's "Found on this page" list.
      reply({ media: msg.tabId != null ? await mediaFor(msg.tabId) : [] });
    } else if (msg.type === "yoinky-send-media") {
      const tab = await chrome.tabs.get(msg.tabId).catch(() => null);
      reply(await sendMedia(msg.media, tab));
    } else if (msg.type === "yoinky-open-app") {
      const found = await findApp(true);
      if (found) {
        await fetch(`http://127.0.0.1:${found.port}/show`, { method: "POST", headers: { "X-Yoinky": "1" } }).catch(() => {});
        reply({ ok: true });
      } else {
        // Closed: open it (the app shows its window when it starts).
        const opened = await launchApp();
        reply(opened.app ? { ok: true } : { ok: false, error: opened.error });
      }
    }
  })();
  return true; // reply asynchronously
});

// ---------------------------------------------------------------- startup

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
chrome.runtime.onStartup.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
// Check in with the app now and then: keeps "connected" status and updates fresh.
chrome.alarms.create("yoinky-ping", { periodInMinutes: 10 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "yoinky-ping") findApp(true);
});
