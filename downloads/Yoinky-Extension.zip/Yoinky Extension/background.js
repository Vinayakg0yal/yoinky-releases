// Yoinky browser extension: hands downloads, videos and images to the Yoinky
// app, which listens on this computer only (127.0.0.1).

const PORTS = [41783, 41784, 41785, 41786, 41787];
const DEFAULTS = { enabled: true, minSizeMB: 1 };

// ---------------------------------------------------------------- settings

async function settings() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

async function updateIcon() {
  const { enabled } = await settings();
  const set = enabled ? "icon" : "off";
  await chrome.action.setIcon({ path: { 16: `icons/${set}16.png`, 32: `icons/${set}32.png` } });
  await chrome.action.setTitle({ title: enabled ? "Yoinky: catching downloads" : "Yoinky: paused" });
}

// ---------------------------------------------------------------- the app

let app = null; // { port, info, at }

// Work in progress (a download being handed over, a button press...). The
// extension never reloads itself in the middle of one.
let busy = 0;
let reloadWanted = false;
async function work(fn) {
  busy++;
  try {
    return await fn();
  } finally {
    busy--;
    if (reloadWanted && busy === 0) setTimeout(reloadWhenIdle, 1500);
  }
}
function reloadWhenIdle() {
  if (busy === 0) chrome.runtime.reload();
}

/** Find the running Yoinky app. Returns its /ping info, or null. */
async function findApp(force = false) {
  if (!force && app && Date.now() - app.at < 30_000) return app;
  const order = app ? [app.port, ...PORTS.filter((p) => p !== app.port)] : PORTS;
  for (const port of order) {
    try {
      // Our ID lets Yoinky register the helper that opens it when it's closed.
      const query = `v=${chrome.runtime.getManifest().version}&id=${chrome.runtime.id}`;
      const res = await fetch(`http://127.0.0.1:${port}/ping?${query}`, {
        headers: { "X-Yoinky": "1" },
        signal: AbortSignal.timeout(800),
      });
      if (!res.ok) continue;
      const info = await res.json();
      if (info.app !== "Yoinky") continue;
      app = { port, info, at: Date.now() };
      maybeSelfUpdate(info);
      return app;
    } catch {
      // Not on this port.
    }
  }
  app = null;
  return null;
}

// ---------------------------------------------------------------- opening Yoinky
// When Yoinky is closed, the browser can start a small helper that Yoinky
// registers for this extension ("native messaging"). It opens the app.

const HOST = "com.yoinky.desktop";
const NOT_SET_UP = "Open the Yoinky app once. After that, Yoinky opens by itself when you download.";

function askHelper(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(HOST, message, (reply) => {
        resolve(chrome.runtime.lastError ? { ok: false, missing: true } : reply || { ok: false });
      });
    } catch {
      resolve({ ok: false, missing: true });
    }
  });
}

/** Open Yoinky and wait until it's ready. Resolves to { app } or { error }. */
async function launchApp() {
  const reply = await askHelper({ type: "launch" });
  if (!reply.ok) return { error: reply.missing ? NOT_SET_UP : "Couldn't open Yoinky. Open it yourself and try again." };
  // It takes a few seconds to start.
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 500));
    chrome.runtime.getPlatformInfo().catch(() => {}); // keeps this worker awake while waiting
    const found = await findApp(true);
    if (found) return { app: found };
  }
  return { error: "Yoinky is taking a while to open. Try again in a moment." };
}

/**
 * Send something to Yoinky. Opens Yoinky first if it's closed (unless
 * `launch` is false). Resolves to { ok, error? }.
 */
async function sendToApp(payload, { launch = true, onLaunching } = {}) {
  let found = await findApp();
  for (let attempt = 0; attempt < 2; attempt++) {
    if (!found) {
      if (!launch) return { ok: false, error: "Yoinky isn't running." };
      onLaunching?.();
      const opened = await launchApp();
      if (!opened.app) return { ok: false, error: opened.error };
      found = opened.app;
    }
    try {
      const res = await fetch(`http://127.0.0.1:${found.port}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Yoinky": "1" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(4000),
      });
      if (!res.ok) return { ok: false, error: `Yoinky said no (${res.status}).` };
      return { ok: true };
    } catch {
      // It was closed a moment ago: look again (and open it if needed).
      app = null;
      found = await findApp(true);
    }
  }
  return { ok: false, error: "Couldn't reach Yoinky." };
}

/** Cookies for a link, so files behind a login download in Yoinky too. */
async function cookiesFor(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

async function payloadFor(url, extra = {}, incognito = false) {
  return {
    url,
    // A private window's sign-in isn't readable here; never send the normal one instead.
    cookies: incognito ? "" : await cookiesFor(url),
    userAgent: navigator.userAgent,
    extensionVersion: chrome.runtime.getManifest().version,
    ...extra,
  };
}

// ---------------------------------------------------------------- updates

const newer = (a, b) => {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
};

/**
 * Yoinky keeps this extension's files up to date (it rewrites them when the
 * app updates). When the app reports a newer version, reload so the browser
 * picks up the new files. Once per version, so it can never loop.
 */
async function maybeSelfUpdate(info) {
  const current = chrome.runtime.getManifest().version;
  const behind = !!info.extensionVersion && newer(info.extensionVersion, current);
  // A small "↑" on the toolbar icon while a newer version is waiting.
  chrome.action.setBadgeBackgroundColor({ color: "#0a7aff" }).catch(() => {});
  chrome.action.setBadgeText({ text: behind ? "↑" : "" }).catch(() => {});
  if (!behind) return;
  const { reloadedFor } = await chrome.storage.local.get("reloadedFor");
  if (reloadedFor === info.extensionVersion) return;
  await chrome.storage.local.set({ reloadedFor: info.extensionVersion });
  // Not in the middle of something: wait until whatever's running is done.
  reloadWanted = true;
  if (busy === 0) setTimeout(reloadWhenIdle, 1500);
}

// ---------------------------------------------------------------- catching downloads

/** Links we hand back to the browser (Yoinky closed, or it refused). */
const passThrough = new Set();

// Files people download from web apps on the fly (exports, reports) usually
// have no size up front and can't be fetched again; leave those to the browser
// unless the name says it's a typical big download.
const BIG_DOWNLOAD = /\.(zip|rar|7z|tar|gz|tgz|bz2|xz|iso|dmg|pkg|exe|msi|apk|deb|rpm|appimage|mp4|mkv|mov|avi|webm|m4v|mp3|flac|wav|m4a|aac|ogg|pdf|epub|psd|ai|bin|img)$/i;

chrome.downloads.onCreated.addListener((item) =>
  work(async () => {
    const url = item.finalUrl || item.url;
    if (passThrough.has(url) || passThrough.has(item.url)) {
      passThrough.delete(url);
      passThrough.delete(item.url);
      return;
    }
    if (item.byExtensionId === chrome.runtime.id) return;
    if (item.incognito) return; // private windows keep their downloads to themselves
    if (!/^https?:/i.test(url)) return; // blob:, data: and file: stay in the browser
    if (item.mime === "text/html") return;

    const { enabled, minSizeMB } = await settings();
    if (!enabled) return;
    if (item.totalBytes > 0 && item.totalBytes < minSizeMB * 1024 * 1024) return;
    const name = (item.filename || "").split(/[\\/]/).pop() || "";
    if (!(item.totalBytes > 0) && !BIG_DOWNLOAD.test(name) && !BIG_DOWNLOAD.test(new URL(url).pathname)) return;
    if (!(await findApp())) return; // Yoinky closed: the browser downloads it as usual

    // Hold the browser's download while Yoinky takes it, so nothing is lost
    // if Yoinky can't: then the browser simply carries on.
    await chrome.downloads.pause(item.id).catch(() => {});
    const result = await sendToApp(
      await payloadFor(url, {
        referrer: item.referrer || "",
        fileName: name,
        size: item.totalBytes > 0 ? item.totalBytes : null,
        source: "download",
      }),
      { launch: false }, // a download the browser started itself: don't open Yoinky for it
    );
    if (result.ok) {
      await chrome.downloads.cancel(item.id).catch(() => {});
      chrome.downloads.erase({ id: item.id }).catch(() => {});
    } else {
      chrome.downloads.resume(item.id).catch(() => {
        // Couldn't resume (some servers don't allow it): start it again.
        passThrough.add(url);
        chrome.downloads.download({ url, filename: name || undefined }).catch(() => passThrough.delete(url));
      });
    }
  }),
);

// ---------------------------------------------------------------- finding media on pages
// Like IDM: watch what each tab loads and remember the videos and audio it
// plays (direct files and HLS/DASH stream playlists), even inside embedded
// players. The video button and the popup then download exactly that.

const STREAM_URL = /\.(m3u8|mpd)(\?|#|$)/i;
const VIDEO_URL = /\.(mp4|m4v|webm|mov|mkv|flv|avi|3gp)(\?|#|$)/i;
const AUDIO_URL = /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|weba)(\?|#|$)/i;
// Pieces of a stream, not something to download on their own.
const SEGMENT_URL = /\.(ts|m4s|cmfv|cmfa|vtt|srt|key)(\?|#|$)|[/_.-](seg|segment|chunk|frag|fragment)[-_]?\d+|\/range\/\d/i;
// Handled by their own page link (yt-dlp knows these sites).
const SKIP_HOSTS = /(^|\.)(googlevideo\.com|youtube\.com|ytimg\.com|fbcdn\.net|cdninstagram\.com|twimg\.com|tiktokcdn\.com)$/i;

const headerOf = (headers, name) => (headers || []).find((h) => h.name.toLowerCase() === name)?.value || "";

function mediaKind(url, type) {
  const t = type.toLowerCase();
  if (t.includes("mpegurl") || t.includes("dash+xml") || STREAM_URL.test(url)) return "stream";
  if (SEGMENT_URL.test(url) || t === "video/mp2t" || t.includes("iso.segment")) return null;
  if (t.startsWith("video/") || VIDEO_URL.test(url)) return "video";
  if (t.startsWith("audio/") || AUDIO_URL.test(url)) return "audio";
  return null;
}

async function mediaFor(tabId) {
  const key = `media:${tabId}`;
  return (await chrome.storage.session.get(key))[key] || [];
}

async function setMediaFor(tabId, list) {
  await chrome.storage.session.set({ [`media:${tabId}`]: list });
  const text = list.length ? String(list.length) : "";
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#0a7aff" }).catch(() => {});
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || (d.statusCode && d.statusCode >= 400)) return;
    if (!/^https?:/i.test(d.url)) return;
    let host = "";
    try {
      host = new URL(d.url).hostname;
    } catch {
      return;
    }
    if (SKIP_HOSTS.test(host)) return;
    const type = headerOf(d.responseHeaders, "content-type");
    const kind = mediaKind(d.url, type);
    if (!kind) return;
    // Real size (a 206 reply's Content-Length is only one piece).
    const range = headerOf(d.responseHeaders, "content-range");
    const size = Number(range.split("/")[1]) || Number(headerOf(d.responseHeaders, "content-length")) || 0;
    if (kind === "video" && size && size < 512 * 1024) return; // previews, ads, thumbnails
    if (kind === "audio" && size && size < 200 * 1024) return; // clicks and blips
    updateMedia(d.tabId, async () => {
      const list = await mediaFor(d.tabId);
      if (list.some((m) => m.url === d.url)) return;
      list.push({
        url: d.url,
        kind,
        size,
        type,
        // The page or embedded player that loaded it: sent as Referer/Origin.
        frameUrl: d.initiator && d.initiator !== "null" ? d.initiator : d.documentUrl || "",
        time: Date.now(),
      });
      await setMediaFor(d.tabId, list.slice(-20));
    });
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other", "object"] },
  ["responseHeaders"],
);

/** One change to a tab's media list at a time (so none get lost). */
const mediaQueues = new Map();
function updateMedia(tabId, fn) {
  const next = (mediaQueues.get(tabId) || Promise.resolve()).then(fn).catch(() => {});
  mediaQueues.set(tabId, next);
  return next;
}

// A new page in the tab (including in-page navigation to another page):
// forget the old page's media. Not when only the #part or a tracking
// parameter changes while the same video keeps playing.
const tabPages = new Map();
const pageOf = (u) => {
  try {
    const x = new URL(u);
    for (const k of [...x.searchParams.keys()]) {
      if (/^(utm_|fbclid$|gclid$|mc_|ref$|si$|t$|time_continue$)/i.test(k)) x.searchParams.delete(k);
    }
    x.searchParams.sort();
    return x.origin + x.pathname + x.search;
  } catch {
    return u;
  }
};
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (!change.url) return;
  const page = pageOf(change.url);
  const before = tabPages.get(tabId);
  tabPages.set(tabId, page);
  if (change.status === "loading" || before !== page) updateMedia(tabId, () => setMediaFor(tabId, []));
});
chrome.tabs.onRemoved.addListener((tabId) => tabPages.delete(tabId));
chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(`media:${tabId}`));

/** The best thing to download from a tab, preferring the frame the user clicked in. */
async function bestMedia(tabId, frameUrl) {
  const list = await mediaFor(tabId);
  if (!list.length) return null;
  let origin = "";
  try {
    origin = new URL(frameUrl).origin;
  } catch {}
  const rank = { stream: 3, video: 2, audio: 1 };
  const score = (m) => (origin && m.frameUrl.startsWith(origin) ? 10 : 0) + rank[m.kind];
  // Highest score; among equals, the first stream playlist (the "master" one
  // listing every quality) or the biggest file.
  return [...list].sort((a, b) => score(b) - score(a) || (a.kind === "stream" ? a.time - b.time : b.size - a.size))[0];
}

/** Send a found video/audio to Yoinky, with what its player would send. */
async function sendMedia(m, tab, options) {
  let origin = "";
  try {
    origin = new URL(m.frameUrl || tab?.url || "").origin;
  } catch {}
  return sendToApp(
    await payloadFor(
      m.url,
      {
        referrer: m.frameUrl ? (m.frameUrl.endsWith("/") ? m.frameUrl : m.frameUrl + "/") : tab?.url || "",
        origin,
        description: tab?.title || "",
        source: m.kind,
      },
      !!tab?.incognito,
    ),
    options,
  );
}

// ---------------------------------------------------------------- right-click menu

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "yoinky-link", title: "Download link with Yoinky", contexts: ["link"] });
    chrome.contextMenus.create({ id: "yoinky-image", title: "Download full-size image with Yoinky", contexts: ["image"] });
    chrome.contextMenus.create({ id: "yoinky-video", title: "Download video with Yoinky", contexts: ["video", "audio"] });
    chrome.contextMenus.create({ id: "yoinky-page", title: "Download this page's video with Yoinky", contexts: ["page"] });
  });
}

/** A short message on the page (from the content script). */
function toastIn(tabId, frameId, text, isError = false) {
  chrome.tabs.sendMessage(tabId, { type: "yoinky-toast", text, isError }, { frameId }).catch(() => {});
}

async function flashBadge(tabId, text, color) {
  if (tabId == null) return;
  await chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
  await chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  // Then back to the tab's own count of found videos.
  setTimeout(async () => setMediaFor(tabId, await mediaFor(tabId)).catch(() => {}), 4000);
}

chrome.contextMenus.onClicked.addListener((info, tab) => work(() => onMenu(info, tab)));

async function onMenu(info, tab) {
  let url = info.pageUrl;
  let source = "page";
  let description = "";
  if (info.menuItemId === "yoinky-link") {
    url = info.linkUrl;
    source = "link";
  } else if (info.menuItemId === "yoinky-image") {
    url = info.srcUrl;
    source = "image";
    // The page's description of the picture helps name the file.
    if (tab?.id != null) {
      try {
        const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-last-description" }, { frameId: info.frameId ?? 0 });
        description = reply?.description || "";
        // Google Images: the result link leads to the full-size original.
        if (reply?.resultLink) url = reply.resultLink;
      } catch {}
    }
  } else if (info.menuItemId === "yoinky-video") {
    // Streamed videos (blob:) can only be downloaded from their page.
    url = info.srcUrl && /^https?:/i.test(info.srcUrl) && !/\.m3u8|\.mpd/i.test(info.srcUrl) ? info.srcUrl : info.pageUrl;
    source = "video";
  }
  if (!url || !/^https?:/i.test(url)) {
    url = info.pageUrl;
    source = "page";
  }
  // Instagram: let the page read the post/story with the browser's sign-in.
  let instagram;
  if (tab?.id != null && /^https:\/\/([^/]+\.)?instagram\.com\//.test(tab.url || "") && /instagram\.com\//.test(url)) {
    try {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-instagram", url }, { frameId: 0 });
      instagram = reply?.data || undefined;
    } catch {}
  }
  const payload = await payloadFor(url, { referrer: info.pageUrl || "", description, source, instagram }, !!tab?.incognito);
  const result = await sendToApp(payload, {
    onLaunching: () => tab?.id != null && toastIn(tab.id, info.frameId ?? 0, "Opening Yoinky…"),
  });
  flashBadge(tab?.id, result.ok ? "✓" : "!", result.ok ? "#22c55e" : "#ef4444");
  if (!result.ok && tab?.id != null) toastIn(tab.id, info.frameId ?? 0, result.error, true);
}

/** Sites Yoinky reads from the page link (not a sniffed stream). */
const KNOWN_SITES = /(^|\.)(youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com|twitch\.tv|instagram\.com|tiktok\.com|facebook\.com|x\.com|twitter\.com|reddit\.com)$/i;
const hostOf = (u) => {
  try {
    return new URL(u).hostname;
  } catch {
    return "";
  }
};

// ---------------------------------------------------------------- messages (popup, video button)

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  work(async () => {
    if (msg.type === "yoinky-status") {
      const found = await findApp(true);
      const version = chrome.runtime.getManifest().version;
      const latest = found?.info.extensionVersion ?? null;
      reply({
        connected: !!found,
        appVersion: found?.info.version ?? null,
        version,
        latestVersion: latest,
        updateAvailable: !!latest && newer(latest, version),
        // Already reloaded for that version and still behind: this copy was
        // loaded from a folder Yoinky doesn't update.
        updateStuck: !!latest && newer(latest, version) && (await chrome.storage.local.get("reloadedFor")).reloadedFor === latest,
        // A newer Yoinky app is out (installed from the Yoinky window).
        appUpdate: found?.info.appUpdate ?? null,
        ...(await settings()),
      });
    } else if (msg.type === "yoinky-update") {
      // Load the new files Yoinky put in the extension folder.
      reply({ ok: true });
      setTimeout(() => chrome.runtime.reload(), 100);
    } else if (msg.type === "yoinky-settings") {
      await chrome.storage.local.set(msg.values);
      await updateIcon();
      reply({ ok: true });
    } else if (msg.type === "yoinky-send") {
      // The video button: download what this player actually plays, if seen.
      const tab = sender.tab;
      const options = {
        onLaunching: () => tab?.id != null && toastIn(tab.id, sender.frameId ?? 0, "Opening Yoinky…"),
      };
      const pageIsKnownSite = KNOWN_SITES.test(hostOf(tab?.url || ""));
      // The button gave the video's own file: use exactly that one. Only
      // when it could only give the page (streamed players) use what the
      // page was seen playing.
      const pageOnly = !msg.url || msg.url === sender.url || msg.url === tab?.url;
      const found =
        msg.source === "video" && pageOnly && !pageIsKnownSite && tab?.id != null ? await bestMedia(tab.id, sender.url || "") : null;
      if (found) {
        reply(await sendMedia(found, tab, options));
      } else {
        const payload = await payloadFor(
          msg.url,
          {
            referrer: sender.url || tab?.url || "",
            description: tab?.title || "",
            source: msg.source || "video",
            // Instagram: the post/story as read in the page (with the browser's sign-in).
            instagram: msg.instagram || undefined,
          },
          !!tab?.incognito,
        );
        reply(await sendToApp(payload, options));
      }
    } else if (msg.type === "yoinky-media") {
      // The popup's "Found on this page" list.
      reply({ media: msg.tabId != null ? await mediaFor(msg.tabId) : [] });
    } else if (msg.type === "yoinky-send-media") {
      const tab = await chrome.tabs.get(msg.tabId).catch(() => null);
      reply(await sendMedia(msg.media, tab));
    } else if (msg.type === "yoinky-open-app") {
      const found = await findApp(true);
      if (found) {
        await fetch(`http://127.0.0.1:${found.port}/show`, { method: "POST", headers: { "X-Yoinky": "1" } }).catch(() => {});
        reply({ ok: true });
      } else {
        // Closed: open it (the app shows its window when it starts).
        const opened = await launchApp();
        reply(opened.app ? { ok: true } : { ok: false, error: opened.error });
      }
    }
  });
  return true; // reply asynchronously
});

// ---------------------------------------------------------------- startup

/**
 * Pages that were open before this install/update still run the old copy of
 * the page script, which can't reach the extension anymore. Give them the new
 * one (it takes over from the old), so nobody has to reload their tabs.
 */
async function refreshOpenTabs() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
  } catch {
    return;
  }
  for (const tab of tabs) {
    if (tab.id == null || tab.discarded) continue;
    const target = { tabId: tab.id, allFrames: true };
    chrome.scripting.insertCSS({ target, files: ["content.css"] }).catch(() => {});
    chrome.scripting.executeScript({ target, files: ["content.js"] }).catch(() => {});
  }
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
  refreshOpenTabs();
});
chrome.runtime.onStartup.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
// Check in with the app now and then: keeps "connected" status and updates fresh.
chrome.alarms.get("yoinky-ping").then((a) => a || chrome.alarms.create("yoinky-ping", { periodInMinutes: 10 }));
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "yoinky-ping") findApp(true);
});
