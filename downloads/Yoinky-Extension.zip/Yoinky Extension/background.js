// Yoinky browser extension: hands downloads, videos and images to the Yoinky
// app, which listens on this computer only (127.0.0.1).

const PORTS = [41783, 41784, 41785, 41786, 41787];
const DEFAULTS = { enabled: true, minSizeMB: 1 };

// ---------------------------------------------------------------- settings

async function settings() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

async function updateIcon() {
  const { enabled } = await settings();
  const set = enabled ? "icon" : "off";
  await chrome.action.setIcon({ path: { 16: `icons/${set}16.png`, 32: `icons/${set}32.png` } });
  await chrome.action.setTitle({ title: enabled ? "Yoinky: catching downloads" : "Yoinky: paused" });
}

// ---------------------------------------------------------------- the app

let app = null; // { port, info, at }

/** Find the running Yoinky app. Returns its /ping info, or null. */
async function findApp(force = false) {
  if (!force && app && Date.now() - app.at < 30_000) return app;
  const order = app ? [app.port, ...PORTS.filter((p) => p !== app.port)] : PORTS;
  for (const port of order) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/ping`, {
        headers: { "X-Yoinky": "1" },
        signal: AbortSignal.timeout(800),
      });
      if (!res.ok) continue;
      const info = await res.json();
      if (info.app !== "Yoinky") continue;
      app = { port, info, at: Date.now() };
      maybeSelfUpdate(info);
      return app;
    } catch {
      // Not on this port.
    }
  }
  app = null;
  return null;
}

/** Send something to Yoinky. Resolves to { ok, error? }. */
async function sendToApp(payload) {
  const found = await findApp();
  if (!found) return { ok: false, error: "Yoinky isn't running. Open the Yoinky app and try again." };
  try {
    const res = await fetch(`http://127.0.0.1:${found.port}/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Yoinky": "1" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) return { ok: false, error: `Yoinky said no (${res.status}).` };
    return { ok: true };
  } catch {
    app = null;
    return { ok: false, error: "Couldn't reach Yoinky." };
  }
}

/** Cookies for a link, so files behind a login download in Yoinky too. */
async function cookiesFor(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

async function payloadFor(url, extra = {}) {
  return {
    url,
    cookies: await cookiesFor(url),
    userAgent: navigator.userAgent,
    extensionVersion: chrome.runtime.getManifest().version,
    ...extra,
  };
}

// ---------------------------------------------------------------- updates

const newer = (a, b) => {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
};

/**
 * Yoinky keeps this extension's files up to date (it rewrites them when the
 * app updates). When the app reports a newer version, reload so the browser
 * picks up the new files. Once per version, so it can never loop.
 */
async function maybeSelfUpdate(info) {
  const current = chrome.runtime.getManifest().version;
  if (!info.extensionVersion || !newer(info.extensionVersion, current)) return;
  const { reloadedFor } = await chrome.storage.local.get("reloadedFor");
  if (reloadedFor === info.extensionVersion) return;
  await chrome.storage.local.set({ reloadedFor: info.extensionVersion });
  chrome.runtime.reload();
}

// ---------------------------------------------------------------- catching downloads

/** Links we hand back to the browser (Yoinky closed, or it refused). */
const passThrough = new Set();

chrome.downloads.onCreated.addListener(async (item) => {
  const url = item.finalUrl || item.url;
  if (passThrough.has(url) || passThrough.has(item.url)) {
    passThrough.delete(url);
    passThrough.delete(item.url);
    return;
  }
  if (item.byExtensionId === chrome.runtime.id) return;
  if (!/^https?:/i.test(url)) return; // blob:, data: and file: stay in the browser
  if (item.mime === "text/html") return;

  const { enabled, minSizeMB } = await settings();
  if (!enabled) return;
  if (item.totalBytes > 0 && item.totalBytes < minSizeMB * 1024 * 1024) return;
  if (!(await findApp())) return; // Yoinky closed: the browser downloads it as usual

  // Take it over from the browser.
  try {
    await chrome.downloads.cancel(item.id);
  } catch {}
  chrome.downloads.erase({ id: item.id }).catch(() => {});

  const result = await sendToApp(
    await payloadFor(url, {
      referrer: item.referrer || "",
      fileName: (item.filename || "").split(/[\\/]/).pop() || "",
      size: item.totalBytes > 0 ? item.totalBytes : null,
      source: "download",
    }),
  );
  if (!result.ok) {
    // Give it back to the browser.
    passThrough.add(url);
    chrome.downloads.download({ url }).catch(() => passThrough.delete(url));
  }
});

// ---------------------------------------------------------------- right-click menu

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "yoinky-link", title: "Download link with Yoinky", contexts: ["link"] });
    chrome.contextMenus.create({ id: "yoinky-image", title: "Download full-size image with Yoinky", contexts: ["image"] });
    chrome.contextMenus.create({ id: "yoinky-video", title: "Download video with Yoinky", contexts: ["video", "audio"] });
    chrome.contextMenus.create({ id: "yoinky-page", title: "Download this page's video with Yoinky", contexts: ["page"] });
  });
}

async function flashBadge(text, color) {
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 4000);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  let url = info.pageUrl;
  let source = "page";
  let description = "";
  if (info.menuItemId === "yoinky-link") {
    url = info.linkUrl;
    source = "link";
  } else if (info.menuItemId === "yoinky-image") {
    url = info.srcUrl;
    source = "image";
    // The page's description of the picture helps name the file.
    if (tab?.id != null) {
      try {
        const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-last-description" });
        description = reply?.description || "";
      } catch {}
    }
  } else if (info.menuItemId === "yoinky-video") {
    // Streamed videos (blob:) can only be downloaded from their page.
    url = info.srcUrl && /^https?:/i.test(info.srcUrl) && !/\.m3u8|\.mpd/i.test(info.srcUrl) ? info.srcUrl : info.pageUrl;
    source = "video";
  }
  if (!url || !/^https?:/i.test(url)) {
    url = info.pageUrl;
    source = "page";
  }
  const result = await sendToApp(await payloadFor(url, { referrer: info.pageUrl || "", description, source }));
  flashBadge(result.ok ? "✓" : "!", result.ok ? "#22c55e" : "#ef4444");
});

// ---------------------------------------------------------------- messages (popup, video button)

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === "yoinky-status") {
      const found = await findApp(true);
      reply({ connected: !!found, appVersion: found?.info.version ?? null, ...(await settings()) });
    } else if (msg.type === "yoinky-settings") {
      await chrome.storage.local.set(msg.values);
      await updateIcon();
      reply({ ok: true });
    } else if (msg.type === "yoinky-send") {
      const url = msg.url;
      reply(await sendToApp(await payloadFor(url, { referrer: sender.tab?.url || "", source: msg.source || "video" })));
    } else if (msg.type === "yoinky-open-app") {
      const found = await findApp(true);
      if (found) {
        await fetch(`http://127.0.0.1:${found.port}/show`, { method: "POST", headers: { "X-Yoinky": "1" } }).catch(() => {});
      }
      reply({ ok: !!found });
    }
  })();
  return true; // reply asynchronously
});

// ---------------------------------------------------------------- startup

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
chrome.runtime.onStartup.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
// Check in with the app now and then: keeps "connected" status and updates fresh.
chrome.alarms.create("yoinky-ping", { periodInMinutes: 10 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "yoinky-ping") findApp(true);
});
