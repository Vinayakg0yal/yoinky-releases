// Yoinky browser extension: hands downloads, videos and images to the Yoinky
// app, which listens on this computer only (127.0.0.1).

const PORTS = [41783, 41784, 41785, 41786, 41787];
const DEFAULTS = { enabled: true, minSizeMB: 1 };

/**
 * Text in the browser's language, from _locales/<language>/messages.json
 * (English when Yoinky doesn't have that language). `subs` fills in $1, $2...
 */
const t = (key, subs) => chrome.i18n.getMessage(key, subs);

// ---------------------------------------------------------------- settings

async function settings() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

// ---------------------------------------------------------------- per-site switches
// The popup's "On this site" switches, saved as
// siteRules: { "example.com": { catch: false, button: false } }.
// A rule for example.com also covers its subdomains (www., shop., ...); the
// most specific rule wins. (content.js has its own copy of siteRuleFor.)

const isIp = (host) => /^\d+(\.\d+){3}$/.test(host) || host.includes(":");

/** What the switches are for a host: { catch, button }. */
function siteRuleFor(rules, host) {
  const out = { catch: true, button: true };
  host = String(host || "").toLowerCase().replace(/\.$/, "");
  if (!host || !rules || typeof rules !== "object") return out;
  const labels = host.split(".");
  const names = isIp(host) ? [host] : labels.map((_, i) => labels.slice(i).join(".")).reverse();
  for (const name of names) {
    const rule = Object.prototype.hasOwnProperty.call(rules, name) ? rules[name] : null;
    if (!rule || typeof rule !== "object") continue;
    if (typeof rule.catch === "boolean") out.catch = rule.catch;
    if (typeof rule.button === "boolean") out.button = rule.button;
  }
  return out;
}

/** The name a site's rule is saved under: www.example.com → example.com. */
function siteKey(host) {
  host = String(host || "").toLowerCase().replace(/\.$/, "");
  return /^www\.[^.]+\.[^.]+/.test(host) ? host.slice(4) : host;
}

function webHost(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? u.hostname : "";
  } catch {
    return "";
  }
}

async function siteState(url) {
  const host = webHost(url);
  if (!host) return null;
  const { siteRules } = await chrome.storage.local.get("siteRules");
  return { key: siteKey(host), ...siteRuleFor(siteRules, host) };
}

// One change at a time, so two quick clicks don't undo each other.
let siteWrites = Promise.resolve();
function setSiteSwitch(url, field, value) {
  const run = async () => {
    const host = webHost(url);
    if (!host || !["catch", "button"].includes(field)) return null;
    const key = siteKey(host);
    const { siteRules } = await chrome.storage.local.get("siteRules");
    const rules = siteRules && typeof siteRules === "object" ? { ...siteRules } : {};
    const own = { ...(rules[key] || {}) };
    own[field] = !!value;
    // Keep only what differs from what the site gets anyway (a wider rule, or on).
    const others = { ...rules };
    delete others[key];
    const inherited = siteRuleFor(others, key);
    for (const f of ["catch", "button"]) if (own[f] === inherited[f]) delete own[f];
    if (Object.keys(own).length) rules[key] = own;
    else delete rules[key];
    await chrome.storage.local.set({ siteRules: rules });
    return siteState(url);
  };
  siteWrites = siteWrites.then(run, run);
  return siteWrites;
}

async function updateIcon() {
  const { enabled } = await settings();
  const set = enabled ? "icon" : "off";
  await chrome.action.setIcon({ path: { 16: `icons/${set}16.png`, 32: `icons/${set}32.png` } });
  await chrome.action.setTitle({ title: t(enabled ? "title_catching" : "title_paused") });
}

// ---------------------------------------------------------------- the app

let app = null; // { port, info, at }

// Work in progress (a download being handed over, a button press...). The
// extension never reloads itself in the middle of one.
let busy = 0;
let reloadWanted = false;
async function work(fn) {
  busy++;
  try {
    return await fn();
  } finally {
    busy--;
    if (reloadWanted && busy === 0) setTimeout(reloadWhenIdle, 1500);
  }
}
function reloadWhenIdle() {
  if (busy === 0) chrome.runtime.reload();
}

/** Find the running Yoinky app. Returns its /ping info, or null. */
async function findApp(force = false) {
  if (!force && app && Date.now() - app.at < 30_000) return app;
  const order = app ? [app.port, ...PORTS.filter((p) => p !== app.port)] : PORTS;
  for (const port of order) {
    try {
      // Our ID lets Yoinky register the helper that opens it when it's closed.
      const query = `v=${chrome.runtime.getManifest().version}&id=${chrome.runtime.id}`;
      const res = await fetch(`http://127.0.0.1:${port}/ping?${query}`, {
        headers: { "X-Yoinky": "1" },
        signal: AbortSignal.timeout(800),
      });
      if (!res.ok) continue;
      const info = await res.json();
      if (info.app !== "Yoinky") continue;
      app = { port, info, at: Date.now() };
      maybeSelfUpdate(info);
      return app;
    } catch {
      // Not on this port.
    }
  }
  app = null;
  return null;
}

// ---------------------------------------------------------------- opening Yoinky
// When Yoinky is closed, the browser can start a small helper that Yoinky
// registers for this extension ("native messaging"). It opens the app.

const HOST = "com.yoinky.desktop";

function askHelper(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(HOST, message, (reply) => {
        resolve(chrome.runtime.lastError ? { ok: false, missing: true } : reply || { ok: false });
      });
    } catch {
      resolve({ ok: false, missing: true });
    }
  });
}

/** Open Yoinky and wait until it's ready. Resolves to { app } or { error }. */
async function launchApp() {
  const reply = await askHelper({ type: "launch" });
  if (!reply.ok) return { error: t(reply.missing ? "err_not_set_up" : "err_open_failed") };
  // It takes a few seconds to start.
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 500));
    chrome.runtime.getPlatformInfo().catch(() => {}); // keeps this worker awake while waiting
    const found = await findApp(true);
    if (found) return { app: found };
  }
  return { error: t("err_slow_to_open") };
}

/**
 * Send something to Yoinky. Opens Yoinky first if it's closed (unless
 * `launch` is false). Resolves to { ok, error? }.
 */
async function sendToApp(payload, { launch = true, onLaunching } = {}) {
  let found = await findApp();
  for (let attempt = 0; attempt < 2; attempt++) {
    if (!found) {
      if (!launch) return { ok: false, error: t("err_not_running") };
      onLaunching?.();
      const opened = await launchApp();
      if (!opened.app) return { ok: false, error: opened.error };
      found = opened.app;
    }
    try {
      const res = await fetch(`http://127.0.0.1:${found.port}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Yoinky": "1" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return { ok: false, error: t("err_refused", [String(res.status)]) };
      return { ok: true };
    } catch (e) {
      // Yoinky got it but is slow to answer: don't send it a second time.
      if (e?.name === "TimeoutError" || e?.name === "AbortError") {
        return { ok: false, error: t("err_no_answer"), timedOut: true };
      }
      // It was closed a moment ago: look again (and open it if needed).
      app = null;
      found = await findApp(true);
    }
  }
  return { ok: false, error: t("err_unreachable") };
}

/**
 * The secret Yoinky saves in this extension's folder. Other extensions can't
 * read this extension's files, so only this one can see and control the
 * downloads. (Not remembered while missing: Yoinky may write it any moment.)
 */
let tokenPromise = null;
function appToken() {
  tokenPromise ||= fetch(chrome.runtime.getURL("yoinky-token.json"))
    .then((r) => (r.ok ? r.json() : null))
    .then((j) => (typeof j?.token === "string" ? j.token : null))
    .catch(() => null)
    .then((t) => {
      if (!t) tokenPromise = null;
      return t;
    });
  return tokenPromise;
}

/**
 * Ask the running Yoinky something (never opens it). Resolves to
 * { res } with its answer, or { error: "closed" | "slow" }.
 */
async function callApp(path, { body, timeout = 3000 } = {}) {
  const found = await findApp();
  if (!found) return { error: "closed" };
  const token = await appToken();
  const headers = { "X-Yoinky": "1" };
  if (body) headers["Content-Type"] = "application/json";
  if (token) headers["X-Yoinky-Token"] = token;
  try {
    const res = await fetch(`http://127.0.0.1:${found.port}${path}`, {
      method: body ? "POST" : "GET",
      headers,
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(timeout),
    });
    // A secret Yoinky turned down (it made a new one, or this copy was set
    // up from another folder): read the file again next time.
    if (res.status === 401 || res.status === 403) tokenPromise = null;
    return { res };
  } catch (e) {
    if (e?.name === "TimeoutError" || e?.name === "AbortError") return { error: "slow" };
    app = null; // closed a moment ago: look for it again next time
    return { error: "closed" };
  }
}

/** The popup's live list: { connected, downloads } or { connected, missing } (older Yoinky). */
async function appDownloads() {
  const { res, error } = await callApp("/downloads", { timeout: 2500 });
  if (error === "slow") return { connected: true, slow: true };
  if (!res) return { connected: false };
  // Yoinky versions from before the list was added.
  if (res.status === 404 || res.status === 405 || res.status === 501) return { connected: true, missing: true };
  // Yoinky doesn't accept this copy's secret: say how to fix it.
  if (res.status === 401 || res.status === 403) return { connected: true, locked: true };
  if (!res.ok) return { connected: true, slow: true };
  try {
    const data = await res.json();
    return { connected: true, downloads: Array.isArray(data?.downloads) ? data.downloads.slice(0, 200) : [] };
  } catch {
    return { connected: true, slow: true };
  }
}

const CONTROL_ACTIONS = ["pause", "resume", "open", "reveal", "remove"];

/** Pause, resume, open... one of Yoinky's downloads. Resolves to { ok, error? }. */
async function controlDownload(id, action) {
  if (!CONTROL_ACTIONS.includes(action) || id == null) return { ok: false, error: t("err_didnt_work") };
  const { res, error } = await callApp("/control", { body: { id, action }, timeout: 5000 });
  if (error === "slow") return { ok: false, error: t("err_no_answer") };
  if (!res) return { ok: false, error: t("err_not_running") };
  if (res.ok) return { ok: true };
  if (res.status === 401 || res.status === 403) return { ok: false, error: t("err_set_up_again") };
  let said = "";
  try {
    said = String((await res.json())?.error || "");
  } catch {}
  return { ok: false, error: said || t("err_cant_do") };
}

/** Cookies for a link, so files behind a login download in Yoinky too. */
async function cookiesFor(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

async function payloadFor(url, extra = {}, incognito = false) {
  return {
    url,
    // A private window's sign-in isn't readable here; never send the normal one instead.
    cookies: incognito ? "" : await cookiesFor(url),
    userAgent: navigator.userAgent,
    extensionVersion: chrome.runtime.getManifest().version,
    ...extra,
  };
}

// ---------------------------------------------------------------- updates

// The extension always carries the same version as the Yoinky app it came
// with. The copy Yoinky ships is the right one, so any difference (newer, or
// "older" like the jump from 1.13.0 to the shared 2.0.0) means: load it.
const differs = (bundled, running) => String(bundled).trim() !== String(running).trim();

/**
 * Yoinky keeps this extension's files up to date (it rewrites them when the
 * app updates). When the app reports a different version, reload so the browser
 * picks up the new files. Once per version, so it can never loop.
 */
async function maybeSelfUpdate(info) {
  const current = chrome.runtime.getManifest().version;
  const behind = !!info.extensionVersion && differs(info.extensionVersion, current);
  // A small "↑" on the toolbar icon while the app's version is waiting.
  chrome.action.setBadgeBackgroundColor({ color: "#536684" }).catch(() => {});
  chrome.action.setBadgeText({ text: behind ? "↑" : "" }).catch(() => {});
  if (!behind) return;
  const { reloadedFor } = await chrome.storage.local.get("reloadedFor");
  if (reloadedFor === info.extensionVersion) return;
  await chrome.storage.local.set({ reloadedFor: info.extensionVersion });
  // Not in the middle of something: wait until whatever's running is done.
  reloadWanted = true;
  if (busy === 0) setTimeout(reloadWhenIdle, 1500);
}

// ---------------------------------------------------------------- catching downloads

/** Links we hand back to the browser (Yoinky closed, or it refused). */
const passThrough = new Set();

// Files people download from web apps on the fly (exports, reports) usually
// have no size up front and can't be fetched again; leave those to the browser
// unless the name says it's a typical big download.
const TORRENT_FILE = /\.torrent$/i;

/**
 * When the person last clicked or typed in a web page. A .torrent download
 * needs one just before it: one a page starts by itself (an ad, or a tab the
 * browser reopens when it starts) stays in the browser rather than popping up
 * in Yoinky. (Kept in session storage too: this worker sleeps between uses.)
 */
let lastGesture = 0;
const GESTURE_WINDOW_MS = 30 * 1000;
async function recentGesture() {
  if (Date.now() - lastGesture < GESTURE_WINDOW_MS) return true;
  const { gestureAt } = (await chrome.storage.session?.get("gestureAt").catch(() => null)) || {};
  return typeof gestureAt === "number" && Date.now() - gestureAt < GESTURE_WINDOW_MS;
}
const BIG_DOWNLOAD = /\.(zip|rar|7z|tar|gz|tgz|bz2|xz|iso|dmg|pkg|exe|msi|apk|deb|rpm|appimage|mp4|mkv|mov|avi|webm|m4v|mp3|flac|wav|m4a|aac|ogg|pdf|epub|psd|ai|bin|img)$/i;

/**
 * The file's name. The browser picks it a moment after the download starts
 * (from the server's answer), so wait for it briefly. "" if it takes longer
 * (for example while a "Save as" window is open).
 */
function fileNameOf(item, waitMs = 1000) {
  const base = (f) => (f || "").split(/[\\/]/).pop() || "";
  if (item.filename) return Promise.resolve(base(item.filename));
  return new Promise((resolve) => {
    let done = false;
    const finish = (name) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.downloads.onChanged.removeListener(onChange);
      resolve(name);
    };
    const onChange = (d) => d.id === item.id && d.filename?.current && finish(base(d.filename.current));
    const timer = setTimeout(() => finish(""), waitMs);
    chrome.downloads.onChanged.addListener(onChange);
    chrome.downloads
      .search({ id: item.id })
      .then(([d]) => d?.filename && finish(base(d.filename)))
      .catch(() => {});
  });
}

/** The page a download came from: its referrer, or else the tab the person is on. */
async function pageOfDownload(item) {
  if (/^https?:/i.test(item.referrer || "")) return item.referrer;
  // No referrer (some links and sites hide it): the tab they just clicked in.
  try {
    let [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    // A link that opened a new, empty tab to download: the page that opened it.
    if (tab && !/^https?:/i.test(tab.url || "") && tab.openerTabId != null) {
      tab = (await chrome.tabs.get(tab.openerTabId).catch(() => null)) || tab;
    }
    return tab?.url || "";
  } catch {
    return "";
  }
}

/**
 * A .torrent file a page downloads by itself (nobody clicked): stopped before
 * it's saved, so the browser can't open it in Yoinky either (when it's set to
 * "always open" .torrent files). Chrome waits for this before finishing a
 * download; anything else goes on at once.
 */
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const url = item.finalUrl || item.url || "";
  let path = "";
  try {
    path = new URL(url).pathname;
  } catch {}
  const torrent = /bittorrent/i.test(item.mime || "") || TORRENT_FILE.test(item.filename || "") || TORRENT_FILE.test(path);
  if (!torrent || item.byExtensionId === chrome.runtime.id || passThrough.has(url)) return; // the browser's own name, now
  (async () => {
    let keep = true;
    try {
      keep = !(await settings()).enabled || (await recentGesture());
    } catch {}
    if (keep) return suggest();
    try {
      await chrome.downloads.cancel(item.id);
      chrome.downloads.erase({ id: item.id }).catch(() => {});
    } catch {
      suggest(); // couldn't stop it: never leave the download waiting
    }
  })();
  return true;
});

chrome.downloads.onCreated.addListener((item) =>
  work(async () => {
    const url = item.finalUrl || item.url;
    if (passThrough.has(url) || passThrough.has(item.url)) {
      passThrough.delete(url);
      passThrough.delete(item.url);
      return;
    }
    if (item.byExtensionId === chrome.runtime.id) return;
    if (item.incognito) return; // private windows keep their downloads to themselves
    if (!/^https?:/i.test(url)) return; // blob:, data: and file: stay in the browser
    if (item.mime === "text/html") return;

    const { enabled, minSizeMB } = await settings();
    if (!enabled) return;
    // .torrent files are small, but always worth catching: Yoinky downloads
    // what's in them.
    // "Catch downloads" switched off for the site this came from.
    const { siteRules } = await chrome.storage.local.get("siteRules");
    if (siteRules && !siteRuleFor(siteRules, webHost(await pageOfDownload(item))).catch) return;
    // Nobody clicked anything: a page started it on its own (an ad, a tab
    // the browser reopened). It stays in the browser, never pops up in Yoinky
    // (and a .torrent like that is stopped: see onDeterminingFilename).
    if (!(await recentGesture())) return;
    const name = await fileNameOf(item);
    const isTorrent = /bittorrent/i.test(item.mime || "") || TORRENT_FILE.test(name) || TORRENT_FILE.test(new URL(url).pathname);
    if (!isTorrent && item.totalBytes > 0 && item.totalBytes < minSizeMB * 1024 * 1024) return;
    if (!isTorrent && !(item.totalBytes > 0) && !BIG_DOWNLOAD.test(name) && !BIG_DOWNLOAD.test(new URL(url).pathname)) return;
    if (!(await findApp())) return; // Yoinky closed: the browser downloads it as usual

    // Hold the browser's download while Yoinky takes it, so nothing is lost
    // if Yoinky can't: then the browser simply carries on.
    await chrome.downloads.pause(item.id).catch(() => {});
    const result = await sendToApp(
      await payloadFor(url, {
        referrer: item.referrer || "",
        fileName: name,
        size: item.totalBytes > 0 ? item.totalBytes : null,
        source: "download",
      }),
      { launch: false }, // a download the browser started itself: don't open Yoinky for it
    );
    if (result.ok) {
      // A small file may have finished already: that copy stays where the
      // browser put it (and in its list); otherwise the browser's is dropped.
      const [now] = await chrome.downloads.search({ id: item.id }).catch(() => []);
      if (now?.state !== "complete") {
        await chrome.downloads.cancel(item.id).catch(() => {});
        chrome.downloads.erase({ id: item.id }).catch(() => {});
      }
    } else {
      chrome.downloads.resume(item.id).catch(() => {
        // Couldn't resume (some servers don't allow it): start it again.
        passThrough.add(url);
        chrome.downloads.download({ url, filename: name || undefined }).catch(() => passThrough.delete(url));
      });
    }
  }),
);

// ---------------------------------------------------------------- finding media on pages
// Like IDM: watch what each tab loads and remember the videos and audio it
// plays (direct files and HLS/DASH stream playlists), even inside embedded
// players. The video button and the popup then download exactly that.

const STREAM_URL = /\.(m3u8|mpd)(\?|#|$)/i;
const VIDEO_URL = /\.(mp4|m4v|webm|mov|mkv|flv|avi|3gp)(\?|#|$)/i;
const AUDIO_URL = /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|weba)(\?|#|$)/i;
// Pieces of a stream, not something to download on their own.
const SEGMENT_URL = /\.(ts|m4s|cmfv|cmfa|vtt|srt|key)(\?|#|$)|[/_.-](seg|segment|chunk|frag|fragment)[-_]?\d+|\/range\/\d/i;
// Handled by their own page link (yt-dlp knows these sites).
const SKIP_HOSTS = /(^|\.)(googlevideo\.com|youtube\.com|ytimg\.com|fbcdn\.net|cdninstagram\.com|twimg\.com|tiktokcdn\.com)$/i;

const headerOf = (headers, name) => (headers || []).find((h) => h.name.toLowerCase() === name)?.value || "";

function mediaKind(url, type) {
  const t = type.toLowerCase();
  if (t.includes("mpegurl") || t.includes("dash+xml") || STREAM_URL.test(url)) return "stream";
  if (SEGMENT_URL.test(url) || t === "video/mp2t" || t.includes("iso.segment")) return null;
  if (t.startsWith("video/") || VIDEO_URL.test(url)) return "video";
  if (t.startsWith("audio/") || AUDIO_URL.test(url)) return "audio";
  return null;
}

async function mediaFor(tabId) {
  const key = `media:${tabId}`;
  return (await chrome.storage.session.get(key))[key] || [];
}

async function setMediaFor(tabId, list) {
  await chrome.storage.session.set({ [`media:${tabId}`]: list });
  const text = list.length ? String(list.length) : "";
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#536684" }).catch(() => {});
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || (d.statusCode && d.statusCode >= 400)) return;
    if (!/^https?:/i.test(d.url)) return;
    let host = "";
    try {
      host = new URL(d.url).hostname;
    } catch {
      return;
    }
    if (SKIP_HOSTS.test(host)) return;
    const type = headerOf(d.responseHeaders, "content-type");
    const kind = mediaKind(d.url, type);
    if (!kind) return;
    // Real size (a 206 reply's Content-Length is only one piece).
    const range = headerOf(d.responseHeaders, "content-range");
    const size = Number(range.split("/")[1]) || Number(headerOf(d.responseHeaders, "content-length")) || 0;
    if (kind === "video" && size && size < 512 * 1024) return; // previews, ads, thumbnails
    if (kind === "audio" && size && size < 200 * 1024) return; // clicks and blips
    updateMedia(d.tabId, async () => {
      const list = await mediaFor(d.tabId);
      if (list.some((m) => m.url === d.url)) return;
      list.push({
        url: d.url,
        kind,
        size,
        type,
        // The page or embedded player that loaded it: sent as Referer/Origin.
        frameUrl: d.initiator && d.initiator !== "null" ? d.initiator : d.documentUrl || "",
        time: Date.now(),
      });
      await setMediaFor(d.tabId, list.slice(-20));
    });
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other", "object"] },
  ["responseHeaders"],
);

/** One change to a tab's media list at a time (so none get lost). */
const mediaQueues = new Map();
function updateMedia(tabId, fn) {
  const next = (mediaQueues.get(tabId) || Promise.resolve()).then(fn).catch(() => {});
  mediaQueues.set(tabId, next);
  return next;
}

// A new page in the tab (including in-page navigation to another page):
// forget the old page's media. Not when only the #part or a tracking
// parameter changes while the same video keeps playing.
const tabPages = new Map();
const pageOf = (u) => {
  try {
    const x = new URL(u);
    for (const k of [...x.searchParams.keys()]) {
      if (/^(utm_|fbclid$|gclid$|mc_|ref$|si$|t$|time_continue$)/i.test(k)) x.searchParams.delete(k);
    }
    x.searchParams.sort();
    return x.origin + x.pathname + x.search;
  } catch {
    return u;
  }
};
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.url) {
    // In-page navigation also reports "loading": compare the pages instead.
    const page = pageOf(change.url);
    const before = tabPages.get(tabId);
    tabPages.set(tabId, page);
    if (before !== page) updateMedia(tabId, () => setMediaFor(tabId, []));
  } else if (change.status === "loading") {
    // The same page loading again (reload).
    updateMedia(tabId, () => setMediaFor(tabId, []));
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  tabPages.delete(tabId);
  mediaQueues.delete(tabId);
  chrome.storage.session.remove(`media:${tabId}`);
});

/** The best thing to download from a tab, preferring the frame the user clicked in. */
async function bestMedia(tabId, frameUrl) {
  const list = await mediaFor(tabId);
  if (!list.length) return null;
  let origin = "";
  try {
    origin = new URL(frameUrl).origin;
  } catch {}
  const rank = { stream: 3, video: 2, audio: 1 };
  const score = (m) => (origin && m.frameUrl.startsWith(origin) ? 10 : 0) + rank[m.kind];
  // Highest score; among equals, the first stream playlist (the "master" one
  // listing every quality) or the biggest file.
  return [...list].sort((a, b) => score(b) - score(a) || (a.kind === "stream" ? a.time - b.time : b.size - a.size))[0];
}

/** Send a found video/audio to Yoinky, with what its player would send. */
async function sendMedia(m, tab, options) {
  let origin = "";
  try {
    origin = new URL(m.frameUrl || tab?.url || "").origin;
  } catch {}
  return sendToApp(
    await payloadFor(
      m.url,
      {
        referrer: m.frameUrl ? (m.frameUrl.endsWith("/") ? m.frameUrl : m.frameUrl + "/") : tab?.url || "",
        origin,
        description: tab?.title || "",
        source: m.kind,
      },
      !!tab?.incognito,
    ),
    options,
  );
}

// ---------------------------------------------------------------- right-click menu

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "yoinky-link", title: t("menu_link"), contexts: ["link"] });
    chrome.contextMenus.create({ id: "yoinky-image", title: t("menu_image"), contexts: ["image"] });
    chrome.contextMenus.create({ id: "yoinky-video", title: t("menu_video"), contexts: ["video", "audio"] });
    chrome.contextMenus.create({ id: "yoinky-page", title: t("menu_page"), contexts: ["page"] });
  });
}

/** A short message on the page (from the content script). */
function toastIn(tabId, frameId, text, isError = false) {
  chrome.tabs.sendMessage(tabId, { type: "yoinky-toast", text, isError }, { frameId }).catch(() => {});
}

async function flashBadge(tabId, text, color) {
  if (tabId == null) return;
  await chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
  await chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  // Then back to the tab's own count of found videos.
  setTimeout(async () => setMediaFor(tabId, await mediaFor(tabId)).catch(() => {}), 4000);
}

chrome.contextMenus.onClicked.addListener((info, tab) => work(() => onMenu(info, tab)));

// Keyboard shortcut (Alt+Shift+Y, changeable in the browser's extension
// shortcuts): download this page's video.
chrome.commands?.onCommand.addListener((command, tab) => {
  if (command !== "download-page" || !tab?.url || !/^https?:/i.test(tab.url)) return;
  work(() => onMenu({ menuItemId: "yoinky-page", pageUrl: tab.url, frameId: 0 }, tab));
});

async function onMenu(info, tab) {
  let url = info.pageUrl;
  let source = "page";
  let description = "";
  let sourcePage = "";
  let sourceOriginal = "";
  if (info.menuItemId === "yoinky-link") {
    url = info.linkUrl;
    source = "link";
  } else if (info.menuItemId === "yoinky-image") {
    url = info.srcUrl;
    source = "image";
    // The page's description of the picture helps name the file.
    if (tab?.id != null) {
      try {
        const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-last-description" }, { frameId: info.frameId ?? 0 });
        description = reply?.description || "";
        // Google Images: the result link leads to the full-size original.
        if (reply?.resultLink) url = reply.resultLink;
        // …and the website it's on, where Yoinky finds the biggest version.
        if (reply?.sourcePage) sourcePage = reply.sourcePage;
        if (reply?.sourceOriginal) sourceOriginal = reply.sourceOriginal;
      } catch {}
    }
  } else if (info.menuItemId === "yoinky-video") {
    // Streamed videos (blob:) can only be downloaded from their page.
    url = info.srcUrl && /^https?:/i.test(info.srcUrl) && !/\.m3u8|\.mpd/i.test(info.srcUrl) ? info.srcUrl : info.pageUrl;
    source = "video";
  }
  if (!url || !/^https?:/i.test(url)) {
    url = info.pageUrl;
    source = "page";
  }
  // Instagram: let the page read the post/story with the browser's sign-in.
  let instagram;
  if (tab?.id != null && /^https:\/\/([^/]+\.)?instagram\.com\//.test(tab.url || "") && /instagram\.com\//.test(url)) {
    try {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: "yoinky-instagram", url }, { frameId: 0 });
      instagram = reply?.data || undefined;
    } catch {}
  }
  const payload = await payloadFor(
    url,
    { referrer: info.pageUrl || "", description, source, instagram, sourcePage: sourcePage || undefined, sourceOriginal: sourceOriginal || undefined },
    !!tab?.incognito,
  );
  const result = await sendToApp(payload, {
    onLaunching: () => tab?.id != null && toastIn(tab.id, info.frameId ?? 0, t("opening_yoinky")),
  });
  flashBadge(tab?.id, result.ok ? "✓" : "!", result.ok ? "#22c55e" : "#ef4444");
  if (!result.ok && tab?.id != null) toastIn(tab.id, info.frameId ?? 0, result.error, true);
}

// ---------------------------------------------------------------- links on a page
// The popup's "Download links from this page…": every link, picture, video
// and audio file on the page (in every frame), sent to Yoinky, which lists
// them so the person can pick what to download.

const MAX_LINKS = 2000;
const LINKS_BUDGET = 3_400_000; // bytes of JSON for the list (Yoinky takes up to about 3.5 MB)

/**
 * Runs inside each frame of the page (so it must not use anything from
 * outside itself). Returns [{ url, text, kind }].
 */
function collectLinksInFrame() {
  const MAX = 4000;
  const found = new Map();
  const here = location.href.split("#")[0];
  const tidy = (s) => String(s || "").replace(/\s+/g, " ").trim().slice(0, 200);
  /** An http(s) address, made absolute; null for javascript:, mailto:, data:, blob:... */
  const web = (raw) => {
    if (typeof raw !== "string" || !raw.trim()) return null;
    try {
      const u = new URL(raw.trim(), document.baseURI);
      return (u.protocol === "http:" || u.protocol === "https:") && u.href.length <= 8192 ? u.href : null;
    } catch {
      return null;
    }
  };
  const add = (raw, text, kind) => {
    const url = web(raw);
    if (!url) return;
    if (kind === "link" && url.split("#")[0] === here) return; // a spot on this same page (#top)
    const had = found.get(url);
    if (had) {
      // A link to a picture that's also shown: it's a picture.
      if (had.kind === "link" && kind !== "link") had.kind = kind;
      if (!had.text) had.text = tidy(text);
      return;
    }
    if (found.size < MAX) found.set(url, { url, text: tidy(text), kind });
  };
  /** srcset="a.jpg 400w, b.jpg 800w" → [{ url, w, x }] */
  const srcset = (value) => {
    const out = [];
    const s = String(value || "");
    let i = 0;
    while (i < s.length) {
      while (i < s.length && (s[i] === "," || /\s/.test(s[i]))) i++;
      if (i >= s.length) break;
      let j = i;
      while (j < s.length && !/\s/.test(s[j])) j++;
      let url = s.slice(i, j);
      let desc = "";
      if (/,$/.test(url)) {
        url = url.replace(/,+$/, "");
      } else {
        let k = j;
        while (k < s.length && s[k] !== ",") k++;
        desc = s.slice(j, k);
        j = k;
      }
      i = j;
      const w = /(\d+(?:\.\d+)?)w/i.exec(desc);
      const x = /(\d+(?:\.\d+)?)x/i.exec(desc);
      out.push({ url, w: w ? +w[1] : 0, x: x ? +x[1] : 1 });
    }
    return out;
  };
  const biggest = (list) => {
    const ok = list.filter((c) => web(c.url));
    if (!ok.length) return null;
    const wide = ok.filter((c) => c.w);
    const pool = wide.length ? wide : ok;
    return pool.reduce((a, b) => ((wide.length ? b.w > a.w : b.x > a.x) ? b : a)).url;
  };
  /** A picture's biggest version. */
  const imageUrl = (img) => {
    const list = srcset(img.getAttribute("srcset"));
    const pic = img.parentElement?.localName === "picture" ? img.parentElement : null;
    if (pic) for (const s of pic.querySelectorAll("source[srcset]")) list.push(...srcset(s.getAttribute("srcset")));
    const best = biggest(list);
    if (best) return best;
    // 1×1 tracking pixels and see-through placeholders aren't pictures.
    const tiny = img.complete && img.naturalWidth > 0 && img.naturalWidth <= 2 && img.naturalHeight <= 2;
    const current = img.currentSrc || img.getAttribute("src");
    if (!tiny && web(current)) return current;
    // Pictures that load when scrolled to keep their real address here.
    for (const name of ["data-src", "data-original", "data-lazy-src", "data-url"]) {
      if (web(img.getAttribute(name))) return img.getAttribute(name);
    }
    return biggest(srcset(img.getAttribute("data-srcset")));
  };
  // The page, and the insides of custom elements (shadow DOM).
  const roots = [document];
  for (let i = 0; i < roots.length && roots.length < 500; i++) {
    for (const el of roots[i].querySelectorAll("*")) if (el.shadowRoot) roots.push(el.shadowRoot);
  }
  for (const root of roots) {
    for (const el of root.querySelectorAll("a[href], area[href], img, video, audio")) {
      const tag = el.localName;
      if (tag === "a" || tag === "area") {
        const text =
          tidy(el.textContent) ||
          tidy(el.getAttribute("title")) ||
          tidy(el.getAttribute("aria-label")) ||
          tidy(el.querySelector?.("img[alt]")?.getAttribute("alt"));
        add(el.getAttribute("href"), text, "link");
      } else if (tag === "img") {
        add(imageUrl(el), el.getAttribute("alt") || el.getAttribute("title"), "image");
      } else {
        const kind = tag === "video" ? "video" : "audio";
        const text = el.getAttribute("title") || el.getAttribute("aria-label") || "";
        add(el.currentSrc, text, kind);
        add(el.getAttribute("src"), text, kind);
        for (const s of el.querySelectorAll("source[src]")) add(s.getAttribute("src"), text, kind);
      }
    }
  }
  return [...found.values()];
}

/** Everything downloadable on a tab, all frames. { links, cut } or null if the page can't be read. */
async function collectPageLinks(tabId) {
  let results;
  try {
    results = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: collectLinksInFrame });
  } catch {
    try {
      // Some frame said no: at least the page itself.
      results = await chrome.scripting.executeScript({ target: { tabId }, func: collectLinksInFrame });
    } catch {
      return null;
    }
  }
  // The page first, then its frames.
  results = [...(results || [])].sort((a, b) => (a.frameId || 0) - (b.frameId || 0));
  const all = new Map();
  let cut = false;
  for (const r of results) {
    if (!Array.isArray(r?.result)) continue;
    for (const l of r.result) {
      if (!l || typeof l.url !== "string") continue;
      const had = all.get(l.url);
      if (had) {
        if (had.kind === "link" && l.kind !== "link") had.kind = l.kind;
        if (!had.text && l.text) had.text = l.text;
      } else if (all.size < MAX_LINKS) {
        all.set(l.url, { url: l.url, text: String(l.text || ""), kind: l.kind });
      } else {
        cut = true;
      }
    }
  }
  // Keep what's sent to a size Yoinky accepts.
  const enc = new TextEncoder();
  const links = [];
  let used = 0;
  for (const l of all.values()) {
    used += enc.encode(JSON.stringify(l)).length + 1;
    if (used > LINKS_BUDGET) {
      cut = true;
      break;
    }
    links.push(l);
  }
  return { links, cut };
}

async function sendPageLinks(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !/^https?:/i.test(tab.url || "")) return { ok: false, error: t("err_web_pages_only") };
  const found = await collectPageLinks(tabId);
  if (!found) return { ok: false, error: t("err_cant_read_page") };
  if (!found.links.length) return { ok: false, empty: true };
  const payload = await payloadFor(
    tab.url,
    { referrer: tab.url, source: "page-links", pageTitle: tab.title || "", links: found.links },
    !!tab.incognito,
  );
  const result = await sendToApp(payload);
  return { ...result, count: found.links.length, cut: found.cut };
}

// ---- Scan this page: everything downloadable, sorted into kinds.
const SCAN_EXT = {
  video: /\.(mp4|m4v|webm|mkv|mov|avi|flv|wmv|mpe?g|ogv|ts|m3u8)(?:[?#]|$)/i,
  audio: /\.(mp3|wav|flac|ogg|oga|m4a|aac|opus|wma|mid|aiff?)(?:[?#]|$)/i,
  image: /\.(jpe?g|png|gif|webp|avif|bmp|svg|tiff?|heic|heif|ico)(?:[?#]|$)/i,
  document: /\.(pdf|docx?|xlsx?|pptx?|odt|ods|odp|rtf|txt|csv|tsv|epub|mobi|djvu)(?:[?#]|$)/i,
  other: /\.(zip|rar|7z|tar|gz|tgz|bz2|xz|zst|iso|dmg|pkg|exe|msi|apk|aab|deb|rpm|appimage|bin|img)(?:[?#]|$)/i,
};
/** Which kind's tab a found item belongs in, or null if it's just a page link. */
function scanCategory(item) {
  if (item.kind === "image") return "image";
  if (item.kind === "audio") return "audio";
  if (item.kind === "video" || item.kind === "stream") return /audio/i.test(item.type || "") ? "audio" : "video";
  for (const cat of ["video", "audio", "image", "document", "other"]) {
    if (SCAN_EXT[cat].test(item.url)) return cat;
  }
  return null; // a link to another page, not a file to download
}

/** Everything downloadable on the tab, grouped by kind, for the popup to show. */
async function scanPage(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !/^https?:/i.test(tab.url || "")) return { ok: false, error: t("err_web_pages_only") };
  const found = await collectPageLinks(tabId);
  if (!found) return { ok: false, error: t("err_cant_read_page") };
  const byUrl = new Map();
  for (const l of found.links) byUrl.set(l.url, { url: l.url, text: l.text || "", kind: l.kind });
  // Merge in the streams/audio the page actually played, so they download too.
  for (const m of await mediaFor(tabId)) {
    const had = byUrl.get(m.url) || { url: m.url, text: "" };
    had.kind = m.kind;
    had.size = m.size;
    had.type = m.type;
    had.media = m;
    byUrl.set(m.url, had);
  }
  const categories = { video: [], audio: [], image: [], document: [], other: [] };
  for (const item of byUrl.values()) {
    const cat = scanCategory(item);
    if (cat && categories[cat].length < 500) categories[cat].push(item);
  }
  return { ok: true, categories, cut: found.cut };
}

/** Send one scanned item (a sniffed stream, or a plain file URL) to Yoinky. */
async function sendScanItem(tabId, item) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return { ok: false, error: t("err_unreachable") };
  if (item.media) return sendMedia(item.media, tab);
  const payload = await payloadFor(
    item.url,
    { referrer: tab.url || "", description: item.text || tab.title || "", source: "page-scan" },
    !!tab.incognito,
  );
  return sendToApp(payload);
}

/** Send every item in one kind's tab at once (as a batch). */
async function sendScanAll(tabId, items) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return { ok: false, error: t("err_unreachable") };
  const links = (items || []).filter((i) => i && typeof i.url === "string").map((i) => ({ url: i.url, text: i.text || "", kind: i.kind }));
  if (!links.length) return { ok: false, empty: true };
  const payload = await payloadFor(tab.url, { referrer: tab.url, source: "page-links", pageTitle: tab.title || "", links }, !!tab.incognito);
  const result = await sendToApp(payload);
  return { ...result, count: links.length };
}

/** Sites Yoinky reads from the page link (not a sniffed stream). */
const KNOWN_SITES = /(^|\.)(youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com|twitch\.tv|instagram\.com|tiktok\.com|facebook\.com|x\.com|twitter\.com|reddit\.com)$/i;
const hostOf = (u) => {
  try {
    return new URL(u).hostname;
  } catch {
    return "";
  }
};

// ---------------------------------------------------------------- messages (popup, video button)

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  // The person clicked or typed in a page (see content.js): kept for a
  // .torrent download that may follow.
  // A picture right-clicked on Google Images: where it comes from (Yoinky
  // keeps it for when that picture's address is copied). Never opens Yoinky.
  if (msg?.type === "yoinky-image-hint") {
    if (!sender.tab?.incognito) {
      work(async () => {
        const { enabled } = await settings();
        const found = enabled && (await findApp());
        if (!found) return;
        await fetch(`http://127.0.0.1:${found.port}/hint`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Yoinky": "1" },
          body: JSON.stringify({ thumb: msg.thumb || "", page: msg.page || "", original: msg.original || "" }),
        }).catch(() => {});
      });
    }
    return false;
  }
  if (msg?.type === "yoinky-gesture") {
    lastGesture = Date.now();
    chrome.storage.session?.set({ gestureAt: lastGesture }).catch(() => {});
    return false;
  }
  work(async () => {
    if (msg.type === "yoinky-status") {
      const found = await findApp(true);
      const version = chrome.runtime.getManifest().version;
      const latest = found?.info.extensionVersion ?? null;
      reply({
        connected: !!found,
        appVersion: found?.info.version ?? null,
        version,
        latestVersion: latest,
        updateAvailable: !!latest && differs(latest, version),
        // Already reloaded for that version and still behind: this copy was
        // loaded from a folder Yoinky doesn't update.
        updateStuck: !!latest && differs(latest, version) && (await chrome.storage.local.get("reloadedFor")).reloadedFor === latest,
        // A newer Yoinky app is out (installed from the Yoinky window).
        appUpdate: found?.info.appUpdate ?? null,
        ...(await settings()),
      });
    } else if (msg.type === "yoinky-update") {
      // Load the new files Yoinky put in the extension folder.
      reply({ ok: true });
      setTimeout(() => chrome.runtime.reload(), 100);
    } else if (msg.type === "yoinky-settings") {
      await chrome.storage.local.set(msg.values);
      await updateIcon();
      reply({ ok: true });
    } else if (msg.type === "yoinky-send") {
      // The video button: download what this player actually plays, if seen.
      const tab = sender.tab;
      const options = {
        onLaunching: () => tab?.id != null && toastIn(tab.id, sender.frameId ?? 0, t("opening_yoinky")),
      };
      const pageIsKnownSite = KNOWN_SITES.test(hostOf(tab?.url || ""));
      // The button gave the video's own file: use exactly that one. Only
      // when it could only give the page (streamed players) use what the
      // page was seen playing.
      const pageOnly = !msg.url || msg.url === sender.url || msg.url === tab?.url;
      const found =
        msg.source === "video" && pageOnly && !pageIsKnownSite && tab?.id != null ? await bestMedia(tab.id, sender.url || "") : null;
      if (found) {
        reply(await sendMedia(found, tab, options));
      } else {
        // An embedded player sending its own page (a YouTube or Vimeo
        // embed): those check which site embeds them.
        const embedPage = sender.frameId && msg.url === sender.url;
        const payload = await payloadFor(
          msg.url,
          {
            referrer: (embedPage ? tab?.url : sender.url) || tab?.url || "",
            description: tab?.title || "",
            source: msg.source || "video",
            // Instagram: the post/story as read in the page (with the browser's sign-in).
            instagram: msg.instagram || undefined,
          },
          !!tab?.incognito,
        );
        reply(await sendToApp(payload, options));
      }
    } else if (msg.type === "yoinky-magnet") {
      // A click on a magnet link: Yoinky opens it when it's running.
      // Otherwise (or when switched off) the browser hands it to the
      // computer's app for magnet links, as usual.
      const tab = sender.tab;
      const page = tab?.url || sender.url || "";
      const { enabled } = await settings();
      const { siteRules } = await chrome.storage.local.get("siteRules");
      const off = !enabled || !!tab?.incognito || (siteRules && !siteRuleFor(siteRules, webHost(page)).catch);
      if (off || typeof msg.url !== "string" || !/^magnet:\?/i.test(msg.url) || !(await findApp())) {
        reply({ ok: false, pass: true });
        return;
      }
      const result = await sendToApp(
        {
          url: msg.url,
          referrer: /^https?:/i.test(sender.url || "") ? sender.url : page,
          userAgent: navigator.userAgent,
          extensionVersion: chrome.runtime.getManifest().version,
          source: "magnet",
        },
        { launch: false },
      );
      // No answer in time: Yoinky most likely has it (don't open it twice).
      reply(result.ok ? { ok: true } : { ok: false, pass: !result.timedOut });
    } else if (msg.type === "yoinky-media") {
      // The popup's "Found on this page" list.
      reply({ media: msg.tabId != null ? await mediaFor(msg.tabId) : [] });
    } else if (msg.type === "yoinky-send-media") {
      const tab = await chrome.tabs.get(msg.tabId).catch(() => null);
      reply(await sendMedia(msg.media, tab));
    } else if (msg.type === "yoinky-downloads") {
      // The popup's live list (it asks about once a second while open).
      reply(await appDownloads());
    } else if (msg.type === "yoinky-control") {
      reply(await controlDownload(msg.id, msg.action));
    } else if (msg.type === "yoinky-site") {
      reply(await siteState(msg.url));
    } else if (msg.type === "yoinky-site-set") {
      reply(await setSiteSwitch(msg.url, msg.field, msg.value));
    } else if (msg.type === "yoinky-send-links") {
      reply(await sendPageLinks(msg.tabId));
    } else if (msg.type === "yoinky-scan-page") {
      reply(await scanPage(msg.tabId));
    } else if (msg.type === "yoinky-scan-send") {
      reply(await sendScanItem(msg.tabId, msg.item));
    } else if (msg.type === "yoinky-scan-all") {
      reply(await sendScanAll(msg.tabId, msg.items));
    } else if (msg.type === "yoinky-open-app") {
      const found = await findApp(true);
      if (found) {
        await fetch(`http://127.0.0.1:${found.port}/show`, { method: "POST", headers: { "X-Yoinky": "1" } }).catch(() => {});
        reply({ ok: true });
      } else {
        // Closed: open it (the app shows its window when it starts).
        const opened = await launchApp();
        reply(opened.app ? { ok: true } : { ok: false, error: opened.error });
      }
    }
  });
  return true; // reply asynchronously
});

// ---------------------------------------------------------------- startup

/**
 * Pages that were open before this install/update still run the old copy of
 * the page script, which can't reach the extension anymore. Give them the new
 * one (it takes over from the old), so nobody has to reload their tabs.
 */
async function refreshOpenTabs() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
  } catch {
    return;
  }
  for (const tab of tabs) {
    if (tab.id == null || tab.discarded) continue;
    const target = { tabId: tab.id, allFrames: true };
    chrome.scripting.insertCSS({ target, files: ["content.css"] }).catch(() => {});
    chrome.scripting.executeScript({ target, files: ["content.js"] }).catch(() => {});
    chrome.scripting.executeScript({ target, files: ["gesture.js"] }).catch(() => {});
  }
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
  refreshOpenTabs();
});
chrome.runtime.onStartup.addListener(() => {
  createMenus();
  updateIcon();
  findApp(true);
});
// Check in with the app now and then: keeps "connected" status and updates fresh.
chrome.alarms.get("yoinky-ping").then((a) => a || chrome.alarms.create("yoinky-ping", { periodInMinutes: 10 }));
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "yoinky-ping") findApp(true);
});
