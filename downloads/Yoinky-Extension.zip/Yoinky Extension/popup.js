const $ = (id) => document.getElementById(id);

async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: "yoinky-status" });
  $("dot").classList.toggle("on", s.connected);
  $("status").textContent = s.connected ? `Connected to Yoinky ${s.appVersion}` : "Yoinky app isn't running";
  $("hint").hidden = s.connected;
  $("enabled").classList.toggle("on", s.enabled);
  $("enabled").setAttribute("aria-checked", String(s.enabled));
  $("min").value = String(s.minSizeMB);
  $("open").hidden = !s.connected;
}

$("enabled").addEventListener("click", async () => {
  const on = !$("enabled").classList.contains("on");
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { enabled: on } });
  refresh();
});
$("min").addEventListener("change", async () => {
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { minSizeMB: Number($("min").value) } });
});
$("open").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "yoinky-open-app" });
  window.close();
});

refresh();
