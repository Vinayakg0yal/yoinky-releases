const $ = (id) => document.getElementById(id);

async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: "yoinky-status" });
  $("dot").classList.toggle("on", s.connected);
  $("status").textContent = s.connected ? `Connected to Yoinky ${s.appVersion}` : "Yoinky is closed";
  $("hint").hidden = s.connected;
  $("enabled").classList.toggle("on", s.enabled);
  $("enabled").setAttribute("aria-checked", String(s.enabled));
  $("min").value = String(s.minSizeMB);
  // Versions, and whether both are up to date.
  const versions = $("versions");
  versions.textContent = `Extension ${s.version}` + (s.appVersion ? ` · Yoinky ${s.appVersion}` : "");
  if (s.connected && !s.updateAvailable && !s.appUpdate) {
    const ok = document.createElement("span");
    ok.className = "ok";
    ok.textContent = " · ✓ Up to date";
    versions.appendChild(ok);
  }
  // Only when there's something to update.
  $("update").hidden = !(s.updateAvailable || s.appUpdate);
  appUpdateOnly = !s.updateAvailable && !!s.appUpdate;
  if (s.updateAvailable) {
    $("update-title").textContent = "Extension update ready";
    $("update-text").textContent = `Version ${s.latestVersion} came with your Yoinky update.`;
    $("update-btn").textContent = "Update";
  } else if (s.appUpdate) {
    $("update-title").textContent = `Yoinky ${s.appUpdate} is available`;
    $("update-text").textContent = "Install it from the Yoinky window.";
    $("update-btn").textContent = "Open Yoinky";
  }
}
let appUpdateOnly = false;

$("enabled").addEventListener("click", async () => {
  const on = !$("enabled").classList.contains("on");
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { enabled: on } });
  refresh();
});
$("min").addEventListener("change", async () => {
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { minSizeMB: Number($("min").value) } });
});
$("open").addEventListener("click", async () => {
  $("open").textContent = "Opening…";
  const r = await chrome.runtime.sendMessage({ type: "yoinky-open-app" });
  if (r?.ok) return window.close();
  $("open").textContent = "Open Yoinky";
  $("hint").hidden = false;
  $("hint").textContent = r?.error || "Couldn't open Yoinky.";
});

// ---- Videos and audio this page has played (found like IDM does).
const sizeText = (n) => (!n ? "" : n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} KB`);
function shortName(url) {
  try {
    const u = new URL(url);
    const last = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || u.hostname);
    return `${last} · ${u.hostname}`;
  } catch {
    return url;
  }
}
async function showFound() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  const { media } = await chrome.runtime.sendMessage({ type: "yoinky-media", tabId: tab.id });
  const list = $("found-list");
  list.textContent = "";
  $("found").hidden = !media.length;
  for (const m of [...media].reverse()) {
    const li = document.createElement("li");
    const kind = m.kind === "audio" ? "♪" : "▶";
    const label = m.kind === "stream" ? "Video stream (all qualities)" : m.kind === "audio" ? "Audio" : "Video";
    li.innerHTML = `<span class="kind">${kind}</span><div class="meta"><div class="name"></div><small></small></div><button class="mini">Download</button>`;
    li.querySelector(".name").textContent = shortName(m.url);
    li.querySelector("small").textContent = [label, sizeText(m.size)].filter(Boolean).join(" · ");
    li.querySelector("button").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      btn.textContent = "Sending…";
      const r = await chrome.runtime.sendMessage({ type: "yoinky-send-media", tabId: tab.id, media: m });
      btn.textContent = r?.ok ? "Sent ✓" : "Try again";
      if (!r?.ok) {
        $("hint").hidden = false;
        $("hint").textContent = r?.error || "Couldn't reach Yoinky.";
      }
    });
    list.appendChild(li);
  }
}
showFound();

$("update-btn").addEventListener("click", async () => {
  if (appUpdateOnly) {
    // The app updates itself from its own window (it shows an Update banner).
    await chrome.runtime.sendMessage({ type: "yoinky-open-app" });
    return window.close();
  }
  $("update-btn").textContent = "Updating…";
  await chrome.runtime.sendMessage({ type: "yoinky-update" });
  window.close();
});

refresh();
