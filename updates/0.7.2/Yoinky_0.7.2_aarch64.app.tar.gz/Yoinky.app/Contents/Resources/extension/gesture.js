// Yoinky: notes when the person clicks or types in a page (their own input,
// not the page's scripts), as early as the page starts. A .torrent download
// that starts with none of this just before it was started by the page on
// its own (an ad, or a tab the browser reopens when it starts), so it stays
// in the browser instead of popping up in Yoinky. Nothing else is sent: no
// addresses, no keys, just "now".
(() => {
  let sent = 0;
  const note = (e) => {
    if (!e.isTrusted) return;
    const now = Date.now();
    if (now - sent < 1000) return;
    sent = now;
    try {
      chrome.runtime.sendMessage({ type: "yoinky-gesture" }).catch(() => {});
    } catch {
      // The extension was updated: this old copy can't reach it anymore.
    }
  };
  window.addEventListener("pointerdown", note, true);
  window.addEventListener("keydown", note, true);
})();
