const $ = (id) => document.getElementById(id);

// ---- Language: Chrome picks _locales/<language>/messages.json for the
// browser's language (English when Yoinky doesn't have it). `subs` fills in $1, $2...
const t = (key, subs) => chrome.i18n.getMessage(key, subs);

/** The page's own text: data-i18n (the text), data-i18n-aria-label, -title and
 *  -placeholder (those attributes); data-i18n-args gives $1, $2... ("|" between). */
function translatePage() {
  document.documentElement.lang = t("html_lang") || "en";
  for (const el of document.querySelectorAll("[data-i18n]")) {
    const text = t(el.dataset.i18n, el.dataset.i18nArgs ? el.dataset.i18nArgs.split("|") : undefined);
    if (text) el.textContent = text;
  }
  for (const attr of ["aria-label", "title", "placeholder"]) {
    for (const el of document.querySelectorAll(`[data-i18n-${attr}]`)) {
      const text = t(el.getAttribute(`data-i18n-${attr}`));
      if (text) el.setAttribute(attr, text);
    }
  }
}
translatePage();

// The tab this popup is about. (The test check opens the popup in a tab of
// its own and names the page with ?tab=.)
const tabReady = (async () => {
  const forced = Number(new URLSearchParams(location.search).get("tab"));
  if (forced) return chrome.tabs.get(forced).catch(() => null);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
})();

// Messages in the grey box under the header (errors and the like).
const HINT = $("hint").textContent;
let saying = false;
function say(text) {
  saying = true;
  $("hint").hidden = false;
  $("hint").textContent = text;
}

let connected = false;
let catchingOn = true;

function setSwitch(el, on) {
  el.classList.toggle("on", !!on);
  el.setAttribute("aria-checked", String(!!on));
}

async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: "yoinky-status" });
  connected = s.connected;
  catchingOn = s.enabled;
  $("dot").classList.toggle("on", s.connected);
  $("status").textContent = s.connected ? t("connected_to", [String(s.appVersion)]) : t("yoinky_closed");
  // The usual hint while Yoinky is closed (unless a message is showing there).
  if (!saying) {
    $("hint").hidden = s.connected;
    $("hint").textContent = HINT;
  }
  setSwitch($("enabled"), s.enabled);
  $("min").value = String(s.minSizeMB);
  paintSite(lastSite);
  // Versions, and whether both are up to date.
  const versions = $("versions");
  versions.textContent = t("extension_version", [String(s.version)]) + (s.appVersion ? ` · Yoinky ${s.appVersion}` : "");
  if (s.connected && !s.updateAvailable && !s.appUpdate) {
    const ok = document.createElement("span");
    ok.className = "ok";
    ok.textContent = ` · ✓ ${t("up_to_date")}`;
    versions.appendChild(ok);
  }
  // Only when there's something to update.
  $("update").hidden = !(s.updateAvailable || s.appUpdate);
  appUpdateOnly = !s.updateAvailable && !!s.appUpdate;
  if (s.updateAvailable && s.updateStuck) {
    // Reloading didn't pick up the new version: this copy was added to the
    // browser from a different folder than the one Yoinky keeps up to date.
    $("update-title").textContent = t("ext_update_ready");
    $("update-text").textContent = t("update_stuck");
    $("update-btn").textContent = t("open_yoinky");
    appUpdateOnly = true;
  } else if (s.updateAvailable) {
    $("update-title").textContent = t("ext_update_ready");
    $("update-text").textContent = t("update_came_with", [String(s.latestVersion)]);
    $("update-btn").textContent = t("update");
  } else if (s.appUpdate) {
    $("update-title").textContent = t("app_update_available", [String(s.appUpdate)]);
    $("update-text").textContent = t("open_to_install");
    $("update-btn").textContent = t("open_yoinky");
  }
}
let appUpdateOnly = false;

$("enabled").addEventListener("click", async () => {
  const on = !$("enabled").classList.contains("on");
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { enabled: on } });
  refresh();
});
$("min").addEventListener("change", async () => {
  await chrome.runtime.sendMessage({ type: "yoinky-settings", values: { minSizeMB: Number($("min").value) } });
});
$("open").addEventListener("click", async () => {
  $("open").textContent = t("opening");
  const r = await chrome.runtime.sendMessage({ type: "yoinky-open-app" });
  if (r?.ok) return window.close();
  $("open").textContent = t("open_yoinky");
  say(r?.error || t("err_couldnt_open"));
});

// ---- Sizes: "12.3 MB", "30 MB", "640 KB"
function bytes(n) {
  n = Number(n) || 0;
  for (const [unit, size] of [["GB", 1e9], ["MB", 1e6]]) {
    if (n >= size) {
      const x = n / size;
      return `${x >= 100 ? Math.round(x) : +x.toFixed(1)} ${unit}`;
    }
  }
  return `${Math.max(1, Math.round(n / 1e3))} KB`;
}

// ---- Videos and audio this page has played (found like IDM does).
function shortName(url) {
  try {
    const u = new URL(url);
    const last = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || u.hostname);
    return `${last} · ${u.hostname}`;
  } catch {
    return url;
  }
}
async function showFound() {
  const tab = await tabReady;
  if (!tab?.id) return;
  const { media } = await chrome.runtime.sendMessage({ type: "yoinky-media", tabId: tab.id });
  const list = $("found-list");
  list.textContent = "";
  $("found").hidden = !media.length;
  for (const m of [...media].reverse()) {
    const li = document.createElement("li");
    const kind = m.kind === "audio" ? "♪" : "▶";
    const label = t(m.kind === "stream" ? "kind_stream" : m.kind === "audio" ? "kind_audio" : "kind_video");
    li.innerHTML = `<span class="kind">${kind}</span><div class="meta"><div class="name"></div><small></small></div><button class="mini"></button>`;
    li.querySelector("button").textContent = t("download");
    li.querySelector(".name").textContent = shortName(m.url);
    li.querySelector("small").textContent = [label, m.size ? bytes(m.size) : ""].filter(Boolean).join(" · ");
    li.querySelector("button").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      btn.textContent = t("sending");
      const r = await chrome.runtime.sendMessage({ type: "yoinky-send-media", tabId: tab.id, media: m });
      btn.textContent = r?.ok ? `${t("sent")} ✓` : t("try_again");
      if (!r?.ok) say(r?.error || t("err_unreachable"));
    });
    list.appendChild(li);
  }
}

// ---- Live downloads (what Yoinky is downloading right now)
const ICONS = {
  pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14" rx="1.2"/><rect x="14" y="5" width="4" height="14" rx="1.2"/></svg>',
  resume: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.6v12.8a1 1 0 0 0 1.53.85l10.2-6.4a1 1 0 0 0 0-1.7L9.53 4.75A1 1 0 0 0 8 5.6z"/></svg>',
  retry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v5h-5"/></svg>',
  open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/></svg>',
  reveal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M3 7.5A1.5 1.5 0 0 1 4.5 6h4.3l2 2h8.7A1.5 1.5 0 0 1 21 9.5v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z"/></svg>',
};
// Which buttons each kind of row gets: [action, icon, label].
const BUTTONS = {
  running: [["pause", "pause", t("pause")]],
  paused: [["resume", "resume", t("resume")]],
  failed: [["resume", "retry", t("try_again")]],
  completed: [["open", "open", t("open")], ["reveal", "reveal", t("show_in_folder")]],
};

function lineFor(d) {
  const total = Number(d.totalBytes) > 0 ? Number(d.totalBytes) : 0;
  const got = Math.max(0, Number(d.downloadedBytes) || 0);
  const pct = total ? Math.min(100, Math.floor((got / total) * 100)) : null;
  switch (d.status) {
    case "queued":
      return t("status_waiting");
    case "paused":
      return pct != null ? `${t("status_paused")} · ${pct}%` : t("status_paused");
    case "failed":
      return d.error ? t("status_failed_reason", [String(d.error)]) : t("status_failed");
    case "completed":
      return total ? `${t("status_done")} · ${bytes(total)}` : t("status_done");
    default: {
      const parts = [];
      if (d.stage) parts.push(d.stage); // "Converting to MP3"
      const finishing = d.stage && total && got >= total;
      if (total && !finishing) parts.push(`${pct}%`, t("size_of_total", [bytes(got), bytes(total)]));
      else if (!total && got) parts.push(bytes(got));
      if (Number(d.speed) > 0) parts.push(`${bytes(d.speed)}/s`);
      return parts.join(" · ") || t("status_starting");
    }
  }
}

const rows = new Map(); // download id → { li, mode }

function makeRow(id) {
  const li = document.createElement("li");
  li.className = "dl";
  li.dataset.id = String(id);
  li.innerHTML = '<div class="meta"><div class="name"></div><div class="bar"><i></i></div><small></small></div><div class="acts"></div>';
  return { li, id, mode: "" };
}

function updateRow(row, d) {
  const { li } = row;
  const status = ["downloading", "queued", "paused", "completed", "failed"].includes(d.status) ? d.status : "downloading";
  li.className = `dl ${status}`;
  const name = String(d.fileName || t("untitled"));
  const nameEl = li.querySelector(".name");
  if (nameEl.textContent !== name) {
    nameEl.textContent = name;
    nameEl.title = name;
  }
  const line = lineFor(d);
  const small = li.querySelector("small");
  if (small.textContent !== line) {
    small.textContent = line;
    small.title = status === "failed" ? line : "";
  }
  // The progress bar: moving when the size isn't known yet (or while converting).
  const total = Number(d.totalBytes) > 0 ? Number(d.totalBytes) : 0;
  const got = Math.max(0, Number(d.downloadedBytes) || 0);
  const busy = status === "downloading" && (!total || (d.stage && got >= total));
  const bar = li.querySelector(".bar");
  bar.classList.toggle("busy", !!busy);
  const width = status === "completed" ? 100 : total && !busy ? Math.min(100, (got / total) * 100) : 0;
  bar.firstElementChild.style.width = busy ? "" : `${width}%`;
  // Buttons, rebuilt only when the kind of row changes (so they don't flicker).
  const mode = status === "downloading" || status === "queued" ? "running" : status;
  if (mode !== row.mode) {
    row.mode = mode;
    const acts = li.querySelector(".acts");
    acts.textContent = "";
    for (const [action, icon, label] of BUTTONS[mode]) {
      const b = document.createElement("button");
      b.className = "icon";
      b.dataset.action = action;
      b.title = label;
      b.setAttribute("aria-label", t("button_for_file", [label, name]));
      b.innerHTML = ICONS[icon];
      b.addEventListener("click", () => control(row.id, action, b));
      acts.appendChild(b);
    }
  }
}

function renderDownloads(list) {
  const ul = $("dl-list");
  const keep = new Set();
  list.forEach((d, i) => {
    if (d == null || d.id == null) return;
    const key = String(d.id);
    if (keep.has(key)) return;
    keep.add(key);
    let row = rows.get(key);
    if (!row) rows.set(key, (row = makeRow(d.id)));
    updateRow(row, d);
    if (ul.children[keep.size - 1] !== row.li) ul.insertBefore(row.li, ul.children[keep.size - 1] || null);
  });
  for (const [key, row] of rows) {
    if (!keep.has(key)) {
      row.li.remove();
      rows.delete(key);
    }
  }
  $("downloads").hidden = !rows.size;
}

async function control(id, action, button) {
  button.disabled = true;
  const r = await chrome.runtime.sendMessage({ type: "yoinky-control", id, action }).catch(() => null);
  if (!r?.ok) say(r?.error || t("err_unreachable"));
  button.disabled = false;
  pollDownloads(); // show the change right away
}

// Asks about once a second while the popup is open (it stops when the popup closes).
let pollTimer = 0;
let polling = false;
let pollAgain = false;
let listGone = false;
let wasConnected = null;
async function pollDownloads() {
  if (listGone) return;
  if (polling) {
    pollAgain = true;
    return;
  }
  polling = true;
  clearTimeout(pollTimer);
  const r = await chrome.runtime.sendMessage({ type: "yoinky-downloads" }).catch(() => null);
  polling = false;
  if (r?.missing) {
    // An older Yoinky without the list: just leave it out.
    listGone = true;
    renderDownloads([]);
    return;
  }
  const isConnected = !!r?.connected;
  // Yoinky was opened or closed while the popup is open.
  if (wasConnected !== null && isConnected !== wasConnected) refresh().catch(() => {});
  wasConnected = isConnected;
  // Yoinky doesn't accept this copy of the extension: say how to fix it
  // instead of just showing no downloads.
  $("locked").hidden = !(isConnected && r.locked);
  if (!isConnected || r.locked) renderDownloads([]);
  else if (!r.slow) renderDownloads(r.downloads || []);
  if (pollAgain) {
    pollAgain = false;
    return pollDownloads();
  }
  pollTimer = setTimeout(pollDownloads, isConnected ? 1000 : 3000);
}
addEventListener("pagehide", () => {
  listGone = true;
  clearTimeout(pollTimer);
});

// ---- On this site: catch downloads / video button
let lastSite = null;
let siteUrl = "";
function paintSite(s) {
  lastSite = s;
  if (!s) {
    $("site").hidden = true;
    return;
  }
  $("site").hidden = false;
  $("site-host").textContent = `(${s.key})`;
  $("site-host").parentElement.title = `${t("on_this_site")} (${s.key})`;
  setSwitch($("site-catch"), s.catch);
  setSwitch($("site-button"), s.button);
  $("site-catch-note").textContent = t(catchingOn ? "site_catch_note" : "site_catch_off_note");
}
for (const [id, field] of [["site-catch", "catch"], ["site-button", "button"]]) {
  $(id).addEventListener("click", async () => {
    if (!siteUrl) return;
    const on = !$(id).classList.contains("on");
    setSwitch($(id), on);
    const s = await chrome.runtime.sendMessage({ type: "yoinky-site-set", url: siteUrl, field, value: on }).catch(() => null);
    if (s) paintSite(s);
  });
}

async function showSite() {
  const tab = await tabReady;
  const onWeb = /^https?:/i.test(tab?.url || "");
  $("links-box").hidden = !onWeb;
  if (!onWeb) return paintSite(null);
  siteUrl = tab.url;
  paintSite(await chrome.runtime.sendMessage({ type: "yoinky-site", url: siteUrl }));
}

// ---- Download links from this page…
$("links").addEventListener("click", async () => {
  const tab = await tabReady;
  const btn = $("links");
  if (!tab?.id || btn.disabled) return;
  btn.disabled = true;
  btn.textContent = t(connected ? "finding_links" : "opening_yoinky");
  const r = await chrome.runtime.sendMessage({ type: "yoinky-send-links", tabId: tab.id }).catch(() => null);
  btn.disabled = false;
  if (r?.ok) {
    const n = Number(r.count).toLocaleString("en-US");
    btn.textContent = r.cut ? t("links_sent_first", [n]) : t(r.count === 1 ? "links_sent_one" : "links_sent_many", [n]);
  } else if (r?.empty) {
    btn.textContent = t("no_links");
  } else {
    btn.textContent = t("try_again");
    say(r?.error || t("err_unreachable"));
  }
});

$("update-btn").addEventListener("click", async () => {
  if (appUpdateOnly) {
    // The app updates itself from its own window (Settings).
    await chrome.runtime.sendMessage({ type: "yoinky-open-app" });
    return window.close();
  }
  $("update-btn").textContent = t("updating");
  await chrome.runtime.sendMessage({ type: "yoinky-update" });
  window.close();
});

showFound();
showSite();
refresh();
pollDownloads();
