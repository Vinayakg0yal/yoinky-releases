// Yoinky: a small "Download" button on videos, and the description of the
// last right-clicked image (used to give the downloaded file a good name).
(() => {
  // After an extension update, the extension puts a fresh copy of this script
  // into pages that were already open. The fresh copy takes over from the old
  // one (which can't reach the extension anymore), so pages never need a reload.
  // (The event name has the extension's id in it, so a web page can't send it.)
  const TAKEOVER = `yoinky-takeover-${chrome.runtime.id}`;
  document.dispatchEvent(new CustomEvent(TAKEOVER));
  // Copies from versions before 1.6 listen for the old name.
  document.dispatchEvent(new CustomEvent("yoinky-takeover"));
  let stopped = false;
  let lastToast = null;

  // Text in the browser's language (_locales; English when Yoinky doesn't have
  // it). Looked up now, while this copy can still reach the extension: the
  // "just updated" message is shown exactly when it no longer can. (The English
  // here is only for a page the extension vanished from mid-load.)
  const t = (key) => {
    try {
      return chrome.i18n.getMessage(key);
    } catch {
      return "";
    }
  };
  const TEXT = {
    button: t("download_with_yoinky") || "Download with Yoinky",
    sent: t("sent_to_yoinky") || "Sent to Yoinky. Pick what to download there.",
    unreachable: t("err_unreachable") || "Couldn't reach Yoinky.",
    updated: t("ext_updated_reload") || "Yoinky's extension was just updated. Reload this page once to use it here.",
  };
  function stopHere() {
    if (stopped) return;
    stopped = true;
    try {
      hide();
      pill.remove();
      // The fresh copy puts its own in.
      document.querySelectorAll(".yoinky-site-btn").forEach((b) => b.remove());
    } catch {}
  }
  document.addEventListener(TAKEOVER, stopHere, { once: true });
  /** This copy can still talk to the extension. */
  const alive = () => {
    if (stopped) return false;
    if (chrome.runtime?.id) return true;
    stopHere(); // the extension was updated and this page wasn't given a fresh copy
    return false;
  };

  // ---- Image descriptions for the right-click menu
  let lastDescription = "";
  /** Google Images: the right-clicked picture's website and original file. */
  let lastSource = null;

  const onGoogle = /(^|\.)google\.[a-z.]+$/.test(location.hostname);
  /** The first ["https://…",height,width] after `from` in Google's page data that isn't Google's own. */
  function originalAfter(text, from) {
    const end = Math.min(text.length, from + 30000);
    let i = from;
    while ((i = text.indexOf('["http', i)) >= 0 && i < end) {
      const close = text.indexOf('"', i + 2);
      if (close < 0) return null;
      const raw = text.slice(i + 2, close);
      if (/^,\d+,\d+\]/.test(text.slice(close + 1, close + 20))) {
        let link = raw;
        try {
          link = JSON.parse(`"${raw}"`);
        } catch {}
        try {
          const host = new URL(link).hostname;
          if (!/gstatic\.com$|(^|\.)google\.|googleusercontent\.com$/.test(host)) return link;
        } catch {}
      }
      i = close + 1;
    }
    return null;
  }
  /**
   * A picture on Google Images: the page it's from (each result carries it as
   * data-lpage) and its original file (in Google's page data, by the result's
   * id). Yoinky looks the picture up there and gets the biggest version.
   */
  function googleSource(img) {
    if (!onGoogle) return null;
    let box = img.closest("[data-lpage]");
    let id = box?.getAttribute("data-docid") || "";
    if (!box) {
      // The big picture of an opened result: its id is in the address.
      const hash = new URLSearchParams(location.hash.slice(1));
      id = hash.get("vhid") || new URLSearchParams(location.search).get("imgrc") || "";
      if (id) box = document.querySelector(`[data-docid="${CSS.escape(id)}"][data-lpage]`);
    }
    const page = box?.getAttribute("data-lpage") || "";
    const src = img.currentSrc || img.src || "";
    let original = "";
    try {
      const host = new URL(src).hostname;
      if (/^https?:/.test(src) && !/gstatic\.com$|(^|\.)google\./.test(host)) original = src;
    } catch {}
    if (!original && id) {
      for (const script of document.scripts) {
        const text = script.textContent || "";
        const at = text.indexOf(id);
        if (at >= 0) {
          original = originalAfter(text, at) || "";
          if (original) break;
        }
      }
    }
    if (!/^https?:/.test(page) && !original) return null;
    return { thumb: /^https?:/.test(src) ? src : "", page: /^https?:/.test(page) ? page : "", original };
  }
  // On Google Images, the thumbnail sits inside a result link that carries the
  // original's address; sending that gets the full-size picture.
  let lastResultLink = "";
  document.addEventListener(
    "contextmenu",
    (e) => {
      if (stopped) return;
      const img = e.target instanceof Element ? e.target.closest("img") : null;
      lastDescription = img ? (img.getAttribute("alt") || img.getAttribute("title") || "").trim() : "";
      lastResultLink = "";
      lastSource = img ? googleSource(img) : null;
      // Right-clicked (often to copy its address): tell Yoinky where it comes
      // from, so a copied preview still gets the full-size picture.
      if (lastSource && alive()) {
        try {
          chrome.runtime.sendMessage({ type: "yoinky-image-hint", ...lastSource }).catch(() => {});
        } catch {}
      }
      const link = img?.closest("a[href]");
      const href = link?.getAttribute("href") || "";
      if (href && /\/imgres\?|[?&]imgurl=|[?&]imgrc=/.test(href)) {
        try {
          lastResultLink = new URL(href, location.href).href;
        } catch {}
      } else if (/(^|\.)google\./.test(location.hostname) && img) {
        // Opened big (the side panel): the big image is the original itself,
        // unless it's still a gstatic preview.
        const src = img.currentSrc || img.src || "";
        if (/^https?:/.test(src) && !/gstatic\.com/.test(src)) lastResultLink = src;
      }
    },
    true,
  );
  // Dragged out of Google Images (onto Yoinky's window, for one): the same
  // note about where the picture comes from.
  document.addEventListener(
    "dragstart",
    (e) => {
      if (stopped || !onGoogle) return;
      const img = e.target instanceof Element ? e.target.closest("img") || e.target.querySelector?.("img") : null;
      const source = img ? googleSource(img) : null;
      if (source && alive()) {
        try {
          chrome.runtime.sendMessage({ type: "yoinky-image-hint", ...source }).catch(() => {});
        } catch {}
      }
    },
    true,
  );
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (stopped) return;
    if (msg?.type === "yoinky-last-description")
      reply({
        description: lastDescription,
        resultLink: lastResultLink || lastSource?.original || "",
        sourcePage: lastSource?.page || "",
        sourceOriginal: lastSource?.original || "",
      });
    // "Opening Yoinky…" and the like, from the extension.
    if (msg?.type === "yoinky-toast" && msg.text) toast(msg.text, !!msg.isError);
    // The right-click menu on Instagram: read the post/story here.
    if (msg?.type === "yoinky-instagram") {
      instagramData(msg.url).then((data) => reply({ data }));
      return true;
    }
  });

  // ---- Magnet links: a click opens them in Yoinky (when it's running),
  // where you pick which files to download. Otherwise the browser does what
  // it always does. (After the page's own click handlers: a page that
  // handles the click itself keeps doing so.)
  window.addEventListener("click", (e) => {
    if (stopped || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target instanceof Element ? e.target.closest("a[href]") : null;
    const href = (a?.getAttribute("href") || "").trim();
    if (!/^magnet:\?/i.test(href)) return;
    // The person's own click only (or a page's button the person just
    // clicked). A page "clicking" a magnet link by itself (ads, tabs the
    // browser reopens when it starts) is stopped here, so it can't open
    // Yoinky through the browser either.
    if (!e.isTrusted && !navigator.userActivation?.isActive) {
      e.preventDefault();
      return;
    }
    if (!alive()) return;
    e.preventDefault();
    // Still within the click's moment, so the browser lets it open the app.
    const passOn = () => {
      try {
        location.assign(href);
      } catch {}
    };
    let answer;
    try {
      answer = chrome.runtime.sendMessage({ type: "yoinky-magnet", url: href });
    } catch {
      passOn();
      return;
    }
    answer.then(
      (r) => {
        if (r?.ok) toast(TEXT.sent);
        else if (r?.pass !== false) passOn();
      },
      passOn,
    );
  });

  const onInstagram = /(^|\.)instagram\.com$/.test(location.hostname);
  const onX = /(^|\.)(x|twitter)\.com$/.test(location.hostname);

  // ---- Instagram, read the way instagram.com itself reads it: from this
  // page, with the browser's own sign-in. Yoinky gets the photo and video
  // addresses and downloads them; nothing else leaves the browser.
  const IG_APP_ID = "936619743392459";
  const IG_CODE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

  function igPk(code) {
    const c = code.length > 28 ? code.slice(0, -28) : code;
    let n = 0n;
    for (const ch of c) {
      const d = IG_CODE.indexOf(ch);
      if (d < 0) return null;
      n = n * 64n + BigInt(d);
    }
    return n > 0n ? n.toString() : null;
  }

  async function igApi(path) {
    const csrf = (document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/) || [])[1] || "";
    let claim = "0";
    try {
      claim = sessionStorage.getItem("www-claim-v2") || "0";
    } catch {}
    const res = await fetch(path, {
      credentials: "include",
      headers: {
        Accept: "*/*",
        "X-IG-App-ID": IG_APP_ID,
        "X-ASBD-ID": "359341",
        "X-CSRFToken": csrf,
        "X-IG-WWW-Claim": claim,
        "X-Requested-With": "XMLHttpRequest",
      },
    });
    if (!res.ok) throw new Error(`Instagram ${res.status}`);
    return res.json();
  }

  /** Just the parts Yoinky needs: the photo/video addresses and sizes. */
  const slim = (m) => ({
    pk: String(m.pk ?? ""),
    media_type: m.media_type,
    video_duration: m.video_duration,
    video_versions: (m.video_versions || []).map((v) => ({ url: v.url, width: v.width, height: v.height })),
    image_versions2: {
      candidates: (m.image_versions2?.candidates || []).map((c) => ({ url: c.url, width: c.width, height: c.height })),
    },
  });

  /** An Instagram post or story's photos and videos, or null. */
  async function instagramData(link) {
    if (!onInstagram) return null;
    let u;
    try {
      u = new URL(link);
    } catch {
      return null;
    }
    if (!/(^|\.)instagram\.com$/.test(u.hostname)) return null;
    const segs = u.pathname.split("/").filter(Boolean);
    try {
      if (segs[0] === "stories" && segs[1]) {
        const highlight = segs[1] === "highlights";
        let reel;
        if (highlight) {
          if (!segs[2]) return null;
          reel = `highlight:${segs[2]}`;
        } else {
          const profile = await igApi(`/api/v1/users/web_profile_info/?username=${encodeURIComponent(segs[1])}`);
          reel = profile?.data?.user?.id;
          if (!reel) return null;
        }
        const data = await igApi(`/api/v1/feed/reels_media/?reel_ids=${encodeURIComponent(reel)}`);
        const r = data?.reels?.[reel] || data?.reels_media?.[0];
        if (!r?.items?.length) return null;
        return {
          kind: "story",
          user: r.user?.username || (highlight ? "" : segs[1]),
          title: r.title || "",
          items: r.items.map(slim),
        };
      }
      const i = segs.findIndex((s) => ["p", "reel", "reels", "tv"].includes(s));
      if (i < 0 || i > 1 || !segs[i + 1]) return null;
      const pk = igPk(segs[i + 1]);
      if (!pk) return null;
      const data = await igApi(`/api/v1/media/${pk}/info/`);
      const m = data?.items?.[0];
      if (!m) return null;
      return {
        kind: "post",
        user: m.user?.username || "",
        caption: m.caption?.text || "",
        items: (m.carousel_media?.length ? m.carousel_media : [m]).map(slim),
      };
    } catch {
      return null; // Yoinky will try on its own
    }
  }

  // ---- Video button
  /** The download arrow, made element by element (YouTube refuses HTML set from text: "Trusted Types"). */
  function downloadIcon(size, stroke = 2) {
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    for (const [k, v] of Object.entries({
      viewBox: "0 0 24 24",
      width: size,
      height: size,
      fill: "none",
      stroke: "currentColor",
      "stroke-width": stroke,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "aria-hidden": "true",
    })) {
      svg.setAttribute(k, String(v));
    }
    const path = document.createElementNS(NS, "path");
    path.setAttribute("d", "M12 4v11M7 10l5 5 5-5M5 20h14");
    svg.appendChild(path);
    return svg;
  }
  // Not on copy-protected (DRM) streaming services: Yoinky can't download those.
  const DRM_HOSTS = /(^|\.)(netflix\.com|disneyplus\.com|primevideo\.com|hulu\.com|max\.com|hbomax\.com|tv\.apple\.com|peacocktv\.com|paramountplus\.com|crave\.ca|crunchyroll\.com|spotify\.com|music\.apple\.com|tidal\.com|deezer\.com)$/i;
  const isAmazonVideo = /(^|\.)amazon\./i.test(location.hostname) && /\/(gp\/)?video\//.test(location.pathname);
  if (DRM_HOSTS.test(location.hostname) || isAmazonVideo) return;

  // A small, see-through round button in the video's top-right corner. It
  // only shows while the pointer moves over a video, fades out when the
  // pointer rests, and turns Yoinky-blue when hovered.
  const pill = document.createElement("button");
  pill.className = "yoinky-pill";
  pill.type = "button";
  pill.setAttribute("aria-label", TEXT.button);
  pill.title = TEXT.button;
  pill.appendChild(downloadIcon(16, 2.4));
  const SIZE = 32;
  const INSET = 12;
  /** Videos and photos with a button among the site's own (see placeYouTubePlayer…): no floating one over them. */
  const ownButton = new WeakSet();
  let current = null;
  let frame = 0;
  let idleTimer = 0;
  let hideTimer = 0;

  /** Instagram and X: the post the video belongs to (in a feed, the page
   *  address is the feed, not the post). Yoinky reads the post from there. */
  function postLink(video) {
    const host = location.hostname;
    const abs = (a) => new URL(a.getAttribute("href"), location.href).href;
    if (/(^|\.)instagram\.com$/.test(host)) {
      // A tile on a profile or Explore page links to its post.
      const own = video.closest('a[href*="/p/"], a[href*="/reel/"]');
      if (own) return abs(own);
      // Already on the post, reel or story.
      if (/^\/((stories|p|reels?|tv)\/|[^/]+\/(p|reel)\/)/.test(location.pathname)) return location.href;
      const box = video.closest("article") || video.closest("[role=dialog]");
      const link = box?.querySelector('a[href*="/p/"], a[href*="/reel/"]');
      return link ? abs(link) : location.href;
    }
    if (/(^|\.)(x|twitter)\.com$/.test(host)) {
      // A photo: its own link (…/status/123/photo/2) picks that photo.
      const photo = video.closest('a[href*="/photo/"]');
      if (photo) return abs(photo);
      const box = video.closest("article");
      const links = [...(box?.querySelectorAll('a[href*="/status/"]') || [])];
      // The post's own link is the one around its time stamp.
      const link = links.find((a) => a.querySelector("time")) || links[0];
      return link ? abs(link).replace(/\/(photo|video|analytics|history)(\/.*)?$/, "") : location.href;
    }
    // Feeds on other video sites: the post's own link, not the feed's address.
    const feed = FEED_LINKS.find((f) => f.host.test(host));
    if (feed) {
      if (feed.single.test(location.pathname + location.search)) return location.href;
      if (feed.attr) {
        const post = closestDeep(video, `[${feed.attr}]`);
        const permalink = post?.getAttribute(feed.attr);
        if (permalink) return new URL(permalink, location.href).href;
      }
      const own = closestDeep(video, feed.links);
      if (own) return abs(own);
      const box = closestDeep(video, feed.box);
      const link = box?.querySelector(feed.links);
      return link ? abs(link) : location.href;
    }
    return null;
  }

  /** Like closest(), but also out of custom players' shadow DOM. */
  function closestDeep(el, selector) {
    for (let n = el; n; ) {
      const hit = n.closest?.(selector);
      if (hit) return hit;
      const root = n.getRootNode?.();
      n = root instanceof ShadowRoot ? root.host : null;
    }
    return null;
  }

  /** Video sites with feeds: what a single video's page looks like, the
   *  links to one, and the box around each post. */
  const FEED_LINKS = [
    {
      host: /(^|\.)facebook\.com$/,
      single: /^\/(watch\/?\?v=|reel\/|[^/]+\/videos\/|share\/[vr]\/)/,
      links: 'a[href*="/videos/"], a[href*="/reel/"], a[href*="/watch/?v="], a[href*="/share/v/"], a[href*="/share/r/"]',
      box: '[role="article"], [data-pagelet^="FeedUnit"]',
    },
    {
      host: /(^|\.)tiktok\.com$/,
      single: /^\/@[^/]+\/(video|photo)\//,
      links: 'a[href*="/video/"]',
      box: '[data-e2e="recommend-list-item-container"], article, [class*="DivItemContainer"]',
    },
    {
      host: /(^|\.)reddit\.com$/,
      single: /^\/r\/[^/]+\/comments\//,
      attr: "permalink",
      links: 'a[href*="/comments/"]',
      box: "shreddit-post, article",
    },
  ];

  function videoUrl(video) {
    const post = postLink(video);
    if (post) return post;
    const src = video.currentSrc || video.src || "";
    // Streamed videos (blob:, HLS, DASH) are downloaded from their page instead.
    if (/^https?:/i.test(src) && !/\.(m3u8|mpd)(\?|$)/i.test(src) && !/youtube\.com|googlevideo\.com/.test(src)) return src;
    return location.href;
  }

  /** Where the button lives: the page, or the full-screen player while full screen. */
  function host() {
    const fs = document.fullscreenElement;
    if (fs && fs.tagName !== "VIDEO") return fs;
    return document.documentElement;
  }

  // ---- Where the button goes: a spot on (or next to) the video where the
  // site has no button of its own, so it never covers the player's or the
  // site's controls (Instagram's "…", X's menus, YouTube's "Share").
  const SPOTS = [
    (r) => [r.right - SIZE - INSET, r.top + INSET], // top right
    (r) => [r.left + INSET, r.top + INSET], // top left
    (r) => [r.left + r.width / 2 - SIZE / 2, r.top + INSET], // top middle
    (r) => [r.right - SIZE - INSET, r.top + r.height / 2 - SIZE / 2], // right middle
    (r) => [r.left + INSET, r.top + r.height / 2 - SIZE / 2], // left middle
    (r) => [r.right - SIZE, r.top - SIZE - 6], // just above, right
    (r) => [r.right + 6, r.top], // just to the right
  ];
  let spot = 0;
  let spotCheckedAt = 0;
  /** The video's size when its spot was picked (picked again only if that changes a lot). */
  let spotFor = { w: 0, h: 0 };

  const CLICKABLE =
    'a[href], button, input, select, textarea, label, summary, [role="button"], [role="link"], [role="menuitem"], [role="slider"], [role="checkbox"], [role="switch"], [role="tab"]';

  /** Is one of the site's own buttons at this point? */
  function siteControlAt(px, py, media, mediaArea) {
    const el = document.elementsFromPoint(px, py).find((e) => e !== pill && !pill.contains(e));
    if (!el || el === media || el.contains(media)) return false;
    // From what's under the point up to the box that holds the video.
    for (let n = el; n && n !== document.body && n !== document.documentElement && !n.contains(media); n = n.parentElement) {
      const b = n.getBoundingClientRect();
      if (b.width * b.height >= mediaArea * 0.6) continue; // an overlay over the whole video
      if (n.matches(CLICKABLE)) return true;
      if (getComputedStyle(n).cursor === "pointer") return true;
    }
    return false;
  }

  function spotIsFree(i, r) {
    const [x, y] = SPOTS[i](r);
    if (x < 4 || y < 4 || x + SIZE > window.innerWidth - 4 || y + SIZE > window.innerHeight - 4) return false;
    const area = r.width * r.height;
    const pad = 3;
    const points = [
      [x + SIZE / 2, y + SIZE / 2],
      [x + pad, y + pad],
      [x + SIZE - pad, y + pad],
      [x + pad, y + SIZE - pad],
      [x + SIZE - pad, y + SIZE - pad],
    ];
    return !points.some(([px, py]) => siteControlAt(px, py, current, area));
  }

  /** Pick the first free spot (checked now and then, not every frame). */
  function chooseSpot(r) {
    const free = SPOTS.findIndex((_, i) => spotIsFree(i, r));
    spot = free >= 0 ? free : -1;
    spotCheckedAt = performance.now();
  }

  /** Follow the video every frame while shown: no lag when the player resizes,
   *  goes full screen or scrolls. Uses transform only, so it's cheap and smooth.
   *  Stops while the button is faded out (the next pointer move restarts it). */
  function follow() {
    frame = 0;
    if (pill.classList.contains("idle")) return;
    if (!current || !current.isConnected) return hide();
    if (document.fullscreenElement && document.fullscreenElement.tagName === "VIDEO") return hide();
    if (pill.parentNode !== host()) host().appendChild(pill);
    const r = current.getBoundingClientRect();
    // One spot per video, picked when the pointer first comes over it, and
    // kept: the button never hops around as the player's own controls come
    // and go. Picked again only when the player changes size a lot (theatre
    // mode, full screen).
    const resized = Math.abs(r.width - spotFor.w) > spotFor.w * 0.15 || Math.abs(r.height - spotFor.h) > spotFor.h * 0.15;
    if (!spotCheckedAt || resized) {
      chooseSpot(r);
      spotFor = { w: r.width, h: r.height };
    } else if (performance.now() - spotCheckedAt > 400) {
      spotCheckedAt = performance.now();
      // The site hid the player, or moved it out from under the pointer
      // (a preview player reused for another thumbnail): don't chase it.
      if (!usable(current) || !(lastX >= r.left && lastX <= r.right && lastY >= r.top && lastY <= r.bottom)) {
        if (!pill.matches(":hover")) return hide();
      }
    }
    // Nowhere free (rare): stay out of the way rather than cover the site's buttons.
    pill.classList.toggle("nowhere", spot < 0);
    const [x, y] = SPOTS[Math.max(spot, 0)](r);
    pill.style.transform = `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
    frame = requestAnimationFrame(follow);
  }

  function show(video) {
    clearTimeout(hideTimer);
    if (current !== video) spotCheckedAt = 0; // new video: find its spot
    current = video;
    pill.classList.add("on");
    pill.classList.remove("idle");
    if (!frame) follow();
    // Fade away when the pointer rests, like the player's own controls.
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (pill.matches(":hover") || pill.classList.contains("busy")) return;
      pill.classList.add("idle");
    }, 2500);
  }

  function hide() {
    clearTimeout(idleTimer);
    pill.classList.remove("on");
    current = null;
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
  }

  function hideSoon() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, 400);
  }

  const bigEnough = (el) => {
    const r = el.getBoundingClientRect();
    return r.width >= 280 && r.height >= 150;
  };

  /** Really on screen: not hidden or faded out by the site. Sites keep
   *  hover-preview players around, invisible, parked over some other
   *  thumbnail; the button mustn't follow those around the page. */
  function isShown(el) {
    if (typeof el.checkVisibility === "function") {
      if (!el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) return false;
    }
    for (let n = el, depth = 0; n && n.nodeType === 1 && depth < 30; depth++) {
      const cs = getComputedStyle(n);
      if (cs.display === "none" || cs.visibility !== "visible" || parseFloat(cs.opacity) < 0.15) return false;
      n = n.parentElement || (n.getRootNode() instanceof ShadowRoot ? n.getRootNode().host : null);
    }
    return true;
  }

  const onYouTube = /(^|\.)youtube\.com$/.test(location.hostname);
  /** YouTube: only the real player (a video's page, Shorts, embedded
   *  players). The little previews that play over thumbnails on the home
   *  page and in search hop from thumbnail to thumbnail, and the mini player
   *  isn't the page's video either. */
  function isYouTubeMainPlayer(video) {
    if (/^\/embed\//.test(location.pathname)) return true;
    // Only where the page itself is one video (not a channel's trailer on
    // its home page, which would send the channel's address).
    if (!/^\/(watch|shorts\/|live\/|clip\/)/.test(location.pathname)) return false;
    if (video.closest("ytd-video-preview, #video-preview, #inline-player, ytd-miniplayer, ytd-thumbnail, yt-lockup-view-model")) {
      return false;
    }
    return !!video.closest("ytd-watch-flexy, ytd-shorts, ytd-reel-video-renderer, #shorts-player, #movie_player");
  }

  /** Instagram and X: photos too (Yoinky offers the whole post, or a story). */
  const isMedia = (el) =>
    el.tagName === "VIDEO" ||
    (el.tagName === "IMG" && (onInstagram || (onX && !!el.closest('a[href*="/photo/"]'))));

  /** A video (or photo) the button can be offered for (not one that has a button among the site's own). */
  const usable = (el) =>
    !ownButton.has(el) && bigEnough(el) && isShown(el) && !(onYouTube && el.tagName === "VIDEO" && !isYouTubeMainPlayer(el));

  function videoUnder(x, y) {
    // What's at the pointer, including what sits under the player's overlays
    // (and one level into players built as custom elements).
    const stack = document.elementsFromPoint(x, y);
    for (const el of stack) {
      if (el === pill) continue;
      if (isMedia(el)) {
        if (usable(el)) return el;
        continue;
      }
      if (el.shadowRoot) {
        const inner = el.shadowRoot.elementsFromPoint(x, y).find((n) => n.tagName === "VIDEO" && usable(n));
        if (inner) return inner;
      }
    }
    // Players that turn off pointer hits on the video itself.
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < 280 || r.height < 150) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && usable(v)) return v;
    }
    return null;
  }

  // ---- On YouTube (videos and Shorts), TikTok, X and Instagram, the button
  // sits among the site's own buttons and looks like them: always in the
  // same place, never over the video, and it comes and goes with the site's
  // own controls. (Everywhere else: the floating button above.)
  const SITE_BTN = "yoinky-site-btn";
  const onTikTok = /(^|\.)tiktok\.com$/.test(location.hostname);
  const LABEL = t("download") || "Download";

  /** Light text on the neighbours' labels ("Share", the counts): a dark page or a
   *  column over the video (YouTube and TikTok have light and dark looks). */
  function darkAround(el) {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let text = null;
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (n.textContent.trim() && n.parentElement && !n.parentElement.closest(`.${SITE_BTN}`)) {
        text = n.parentElement;
        break;
      }
    }
    const c = (getComputedStyle(text || el).color.match(/[\d.]+/g) || ["255", "255", "255"]).map(Number);
    return c[0] * 0.299 + c[1] * 0.587 + c[2] * 0.114 > 128;
  }

  /**
   * Yoinky's button for one place on a site. kinds: "ytp" (YouTube's player
   * bar), "column" (round button with a label: Shorts, TikTok), "x" (X's row
   * under a post), "ig" (Instagram's row or column of icons).
   */
  function siteButton(kind, getUrl, around) {
    const b = document.createElement(kind === "column" ? "div" : "button");
    b.className = `${SITE_BTN} yoinky-${kind}`;
    b.setAttribute("aria-label", TEXT.button);
    b.title = TEXT.button;
    if (kind === "column") {
      b.setAttribute("role", "button");
      b.tabIndex = 0;
      const circle = document.createElement("span");
      circle.className = "yoinky-column-circle";
      circle.appendChild(downloadIcon(24));
      const label = document.createElement("span");
      label.className = "yoinky-column-label";
      label.textContent = LABEL;
      b.append(circle, label);
      b.classList.toggle("light", !darkAround(around));
    } else {
      b.type = "button";
      if (kind === "ytp") b.classList.add("ytp-button");
      b.appendChild(downloadIcon(kind === "x" ? 19 : 24));
    }
    const go = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!e.isTrusted || !buttonOn || !alive()) return; // a real click only, not the page's script
      sendToYoinky(getUrl, b);
    };
    b.addEventListener("click", go);
    b.addEventListener("keydown", (e) => (e.key === "Enter" || e.key === " ") && go(e));
    // Not a click on the player or the post behind it (play/pause, opening the post).
    for (const type of ["mousedown", "mouseup", "pointerdown", "pointerup", "dblclick"]) {
      b.addEventListener(type, (e) => e.stopPropagation());
    }
    return b;
  }
  const hasOwn = (box) => !!box.querySelector(`:scope > .${SITE_BTN}`);

  /** YouTube's player bar (videos, embedded players, the mini player), at the start of its right-hand buttons. */
  function placeYouTubePlayer() {
    for (const bar of document.querySelectorAll(".ytp-right-controls-left, .ytp-right-controls")) {
      // The newer player splits its right-hand buttons in two groups: the first one.
      if (bar.classList.contains("ytp-right-controls") && bar.querySelector(".ytp-right-controls-left")) continue;
      const player = bar.closest(".html5-video-player");
      const video = player?.querySelector("video");
      if (!player || !video) continue;
      // Previews over thumbnails and Shorts (their buttons are beside the video).
      if (player.closest("ytd-shorts, ytd-reel-video-renderer, ytd-video-preview, #video-preview, #inline-player")) continue;
      ownButton.add(video);
      if (hasOwn(bar)) continue;
      bar.insertBefore(
        siteButton("ytp", () => {
          // The video playing in the player (also in the mini player, when
          // the page shows something else).
          const title = player.querySelector("a.ytp-title-link[href]")?.href || "";
          if (/[?&]v=|youtu\.be\//.test(title)) return title;
          const id = !/^\/embed\//.test(location.pathname) && document.querySelector("ytd-watch-flexy[video-id]")?.getAttribute("video-id");
          return id && /^[\w-]{6,}$/.test(id) ? `https://www.youtube.com/watch?v=${id}` : location.href;
        }),
        bar.firstChild,
      );
    }
  }

  /** YouTube Shorts: in the column beside the video, after Share. */
  function placeShorts() {
    for (const bar of document.querySelectorAll("reel-action-bar-view-model, ytd-reel-player-overlay-renderer #actions")) {
      const reel = bar.closest("ytd-reel-video-renderer, ytd-shorts");
      const video = reel?.querySelector("video");
      if (video) ownButton.add(video);
      if (hasOwn(bar)) continue;
      const buttons = [...bar.children].filter((c) => /button-view-model|ytd-button-renderer/i.test(c.tagName) && !/like/i.test(c.tagName));
      // Comment, Share, Remix…: after the second (Share), else at the end of the buttons.
      const after = buttons.length >= 3 ? buttons[1] : buttons[buttons.length - 1];
      const button = siteButton("column", () => (/^\/shorts\//.test(location.pathname) ? location.href : video ? videoUrl(video) : location.href), bar);
      if (after) after.after(button);
      else bar.appendChild(button);
    }
  }

  /** TikTok: in the column beside the video, after Share. */
  function placeTikTok() {
    for (const share of document.querySelectorAll('[data-e2e="share-icon"]')) {
      const bar = share.closest("section") || share.parentElement?.parentElement;
      const item = bar && [...bar.children].find((c) => c.contains(share));
      if (!item) continue;
      const box = bar.closest('article, [data-e2e="recommend-list-item-container"]');
      const video = box?.querySelector("video") || (!box && document.querySelector("video"));
      if (video) ownButton.add(video);
      if (hasOwn(bar)) continue;
      item.after(siteButton("column", () => (/\/(video|photo)\//.test(location.pathname) && !box ? location.href : video ? videoUrl(video) : location.href), bar));
    }
  }

  /** X: in the row under a post with videos or photos, before Bookmark. */
  function placeX() {
    for (const post of document.querySelectorAll('article[data-testid="tweet"]')) {
      const media = post.querySelectorAll('[data-testid="videoPlayer"] video, [data-testid="tweetPhoto"] img, video');
      if (!media.length) continue;
      media.forEach((m) => ownButton.add(m));
      const groups = post.querySelectorAll('[role="group"]');
      const bar = groups[groups.length - 1];
      if (!bar || hasOwn(bar)) continue;
      const bookmark = [...bar.children].find((c) => c.querySelector('[data-testid="bookmark"], [data-testid="removeBookmark"]'));
      const button = siteButton("x", () => {
        const links = [...post.querySelectorAll('a[href*="/status/"]')];
        const link = links.find((a) => a.querySelector("time")) || links[0];
        return link ? new URL(link.getAttribute("href"), location.href).href.replace(/\/(photo|video|analytics|history)(\/.*)?$/, "") : location.href;
      });
      bar.insertBefore(button, bookmark || bar.lastElementChild);
    }
  }

  /** Instagram: next to Save (in a post's row of icons, or a reel's column). */
  const IG_SAVE = 'svg polygon[points="20 21 12 13.44 4 21 4 3 20 3 20 21"], svg[aria-label="Save"], svg[aria-label="Remove"]';
  function placeInstagram() {
    for (const mark of document.querySelectorAll(IG_SAVE)) {
      const svg = mark.closest("svg");
      let item = svg;
      while (item?.parentElement && item.parentElement.children.length === 1) item = item.parentElement;
      const row = item?.parentElement;
      if (!row || row === document.body) continue;
      // The post or reel it's for: the nearest box around it with a video or photo.
      let box = svg.closest("article");
      for (let n = row, i = 0; !box && n && i < 8; n = n.parentElement, i++) {
        if (n.querySelector("video, img[srcset]")) box = n;
      }
      const media = box ? [...box.querySelectorAll("video, img[srcset]")] : [];
      media.forEach((m) => ownButton.add(m));
      if (hasOwn(row)) continue;
      const column = getComputedStyle(row).flexDirection.startsWith("column");
      // A post's row: Like, Comment, Repost, Share on the left and Save on the
      // right. It goes after Share (next to Save, it pushed Save onto a new line).
      const left = column ? null : item.previousElementSibling;
      if (left && hasOwn(left)) continue;
      const button = siteButton("ig", () => {
        const first = media.find((m) => m.tagName === "VIDEO") || media[0];
        const own = box?.querySelector('a[href*="/p/"], a[href*="/reel/"]');
        if (/^\/((stories|p|reels?|tv)\/|[^/]+\/(p|reel)\/)/.test(location.pathname) && !svg.closest("article")) return location.href;
        if (own) return new URL(own.getAttribute("href"), location.href).href;
        return first ? videoUrl(first) : location.href;
      });
      button.classList.add(column ? "column" : "row");
      if (left) left.appendChild(button);
      else row.insertBefore(button, item);
    }
  }

  const PLACERS = [
    onYouTube && placeYouTubePlayer,
    onYouTube && placeShorts,
    onTikTok && placeTikTok,
    onX && placeX,
    onInstagram && placeInstagram,
  ].filter(Boolean);
  let placing = 0;
  /** Add the buttons where they're missing (the sites build their pages as you scroll). */
  function placeSoon() {
    if (placing || stopped) return;
    placing = setTimeout(() => {
      placing = 0;
      if (stopped || !buttonOn || !alive()) return;
      for (const place of PLACERS) {
        try {
          place();
        } catch {}
      }
    }, 250);
  }
  function removeSiteButtons() {
    document.querySelectorAll(`.${SITE_BTN}`).forEach((b) => b.remove());
  }
  if (PLACERS.length) {
    new MutationObserver(placeSoon).observe(document.documentElement, { childList: true, subtree: true });
    placeSoon();
  }

  // ---- "Video button" switched off for this site in the popup. The site is
  // the page in the address bar, also for players embedded in it. Follows the
  // switch right away (no reload needed).
  let buttonOn = true;
  const pageHost = (() => {
    try {
      const up = location.ancestorOrigins;
      if (up && up.length) return new URL(up[up.length - 1]).hostname || location.hostname;
    } catch {}
    return location.hostname;
  })();
  /** Same as siteRuleFor in background.js: a rule for example.com covers its subdomains too. */
  function buttonAllowed(rules) {
    let on = true;
    const host = pageHost.toLowerCase().replace(/\.$/, "");
    if (!host || !rules || typeof rules !== "object") return on;
    const labels = host.split(".");
    const ip = /^\d+(\.\d+){3}$/.test(host) || host.includes(":");
    const names = ip ? [host] : labels.map((_, i) => labels.slice(i).join(".")).reverse();
    for (const name of names) {
      const rule = Object.prototype.hasOwnProperty.call(rules, name) ? rules[name] : null;
      if (rule && typeof rule.button === "boolean") on = rule.button;
    }
    return on;
  }
  function applySiteRules(rules) {
    if (stopped) return;
    buttonOn = buttonAllowed(rules);
    if (!buttonOn && current) hide();
    if (!buttonOn) removeSiteButtons();
    else placeSoon();
  }
  try {
    chrome.storage.local.get("siteRules").then((s) => applySiteRules(s.siteRules), () => {});
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.siteRules) applySiteRules(changes.siteRules.newValue);
    });
  } catch {}

  // mousemove (not just mouseover), so it reappears when the pointer moves again.
  let lastMove = 0;
  let lastX = -1;
  let lastY = -1;
  document.addEventListener(
    "mousemove",
    (e) => {
      lastX = e.clientX;
      lastY = e.clientY;
      const now = performance.now();
      if (now - lastMove < 50) return; // plenty, and keeps it light
      lastMove = now;
      if (!e.isTrusted || !alive()) return;
      if (!buttonOn) {
        if (current) hide();
        return;
      }
      if (e.target === pill || pill.contains(e.target)) {
        clearTimeout(hideTimer);
        clearTimeout(idleTimer);
        pill.classList.remove("idle");
        if (!frame && current) follow();
        return;
      }
      const video = videoUnder(e.clientX, e.clientY);
      if (video) show(video);
      else if (current) hideSoon();
    },
    true,
  );
  document.addEventListener("mouseleave", () => !stopped && current && hideSoon());

  let sending = false;
  /** Send a video's (or post's) link to Yoinky; `button` shows it's busy meanwhile. */
  async function sendToYoinky(getUrl, button) {
    if (sending) return; // a double-click sends it once
    sending = true;
    button.classList.add("busy");
    let result;
    try {
      const url = getUrl();
      // Instagram: read the post/story here, with this browser's sign-in.
      const instagram = await instagramData(url);
      result = await chrome.runtime.sendMessage({ type: "yoinky-send", url, source: "video", instagram });
    } catch {
      // Only if this page couldn't be given the updated extension.
      stopHere();
      result = { ok: false, error: TEXT.updated };
    }
    button.classList.remove("busy");
    // A moment more, so the second click of a double-click is ignored too.
    setTimeout(() => (sending = false), 600);
    toast(result?.ok ? TEXT.sent : result?.error || TEXT.unreachable, !result?.ok);
  }
  pill.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!e.isTrusted || !current || !buttonOn || !alive()) return; // a real click only, not the page's script
    const video = current;
    sendToYoinky(() => videoUrl(video), pill);
  });
  // Don't let the player treat the click as play/pause.
  for (const type of ["mousedown", "mouseup", "dblclick", "pointerdown", "pointerup"]) {
    pill.addEventListener(type, (e) => e.stopPropagation());
  }

  function toast(text, isError) {
    lastToast?.remove(); // one at a time ("Opening Yoinky…" → "Sent to Yoinky")
    const t = document.createElement("div");
    lastToast = t;
    t.className = `yoinky-toast${isError ? " error" : ""}`;
    t.textContent = text;
    host().appendChild(t);
    requestAnimationFrame(() => t.classList.add("on"));
    setTimeout(() => {
      t.classList.remove("on");
      setTimeout(() => t.remove(), 300);
    }, 3200);
  }
})();
