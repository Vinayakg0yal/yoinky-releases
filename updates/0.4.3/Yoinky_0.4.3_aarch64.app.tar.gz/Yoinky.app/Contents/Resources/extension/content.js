// Yoinky: a small "Download" button on videos, and the description of the
// last right-clicked image (used to give the downloaded file a good name).
(() => {
  if (window.__yoinky) return;
  window.__yoinky = true;

  // ---- Image descriptions for the right-click menu
  let lastDescription = "";
  // On Google Images, the thumbnail sits inside a result link that carries the
  // original's address; sending that gets the full-size picture.
  let lastResultLink = "";
  document.addEventListener(
    "contextmenu",
    (e) => {
      const img = e.target instanceof Element ? e.target.closest("img") : null;
      lastDescription = img ? (img.getAttribute("alt") || img.getAttribute("title") || "").trim() : "";
      lastResultLink = "";
      const link = img?.closest("a[href]");
      const href = link?.getAttribute("href") || "";
      if (href && /\/imgres\?|[?&]imgurl=|[?&]imgrc=/.test(href)) {
        try {
          lastResultLink = new URL(href, location.href).href;
        } catch {}
      } else if (/(^|\.)google\./.test(location.hostname) && img) {
        // Opened big (the side panel): the big image is the original itself,
        // unless it's still a gstatic preview.
        const src = img.currentSrc || img.src || "";
        if (/^https?:/.test(src) && !/gstatic\.com/.test(src)) lastResultLink = src;
      }
    },
    true,
  );
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg?.type === "yoinky-last-description") reply({ description: lastDescription, resultLink: lastResultLink });
  });

  // ---- Video button
  // Not on copy-protected (DRM) streaming services: Yoinky can't download those.
  const DRM_HOSTS = /(^|\.)(netflix\.com|disneyplus\.com|primevideo\.com|hulu\.com|max\.com|hbomax\.com|tv\.apple\.com|peacocktv\.com|paramountplus\.com|crave\.ca|crunchyroll\.com|spotify\.com|music\.apple\.com|tidal\.com|deezer\.com)$/i;
  const isAmazonVideo = /(^|\.)amazon\./i.test(location.hostname) && /\/(gp\/)?video\//.test(location.pathname);
  if (DRM_HOSTS.test(location.hostname) || isAmazonVideo) return;

  // A small, see-through round button in the video's top-right corner. It
  // only shows while the pointer moves over a video, fades out when the
  // pointer rests, and turns Yoinky-blue when hovered.
  const pill = document.createElement("button");
  pill.className = "yoinky-pill";
  pill.type = "button";
  pill.setAttribute("aria-label", "Download this video with Yoinky");
  pill.innerHTML =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>';
  const SIZE = 32;
  const INSET = 12;
  let current = null;
  let frame = 0;
  let idleTimer = 0;
  let hideTimer = 0;

  function videoUrl(video) {
    const src = video.currentSrc || video.src || "";
    // Streamed videos (blob:, HLS, DASH) are downloaded from their page instead.
    if (/^https?:/i.test(src) && !/\.(m3u8|mpd)(\?|$)/i.test(src) && !/youtube\.com|googlevideo\.com/.test(src)) return src;
    return location.href;
  }

  /** Where the button lives: the page, or the full-screen player while full screen. */
  function host() {
    const fs = document.fullscreenElement;
    if (fs && fs.tagName !== "VIDEO") return fs;
    return document.documentElement;
  }

  /** Follow the video every frame while shown: no lag when the player resizes,
   *  goes full screen or scrolls. Uses transform only, so it's cheap and smooth. */
  function follow() {
    frame = 0;
    if (!current || !current.isConnected) return hide();
    if (document.fullscreenElement && document.fullscreenElement.tagName === "VIDEO") return hide();
    if (pill.parentNode !== host()) host().appendChild(pill);
    const r = current.getBoundingClientRect();
    const x = Math.min(window.innerWidth - SIZE - 6, r.right - SIZE - INSET);
    const y = Math.max(6, r.top + INSET);
    pill.style.transform = `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
    frame = requestAnimationFrame(follow);
  }

  function show(video) {
    clearTimeout(hideTimer);
    current = video;
    pill.classList.add("on");
    pill.classList.remove("idle");
    if (!frame) follow();
    // Fade away when the pointer rests, like the player's own controls.
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => pill.classList.add("idle"), 2500);
  }

  function hide() {
    clearTimeout(idleTimer);
    pill.classList.remove("on");
    current = null;
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
  }

  function hideSoon() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, 400);
  }

  function videoUnder(x, y) {
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < 280 || r.height < 150) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return v;
    }
    return null;
  }

  // mousemove (not just mouseover), so it reappears when the pointer moves again.
  let lastMove = 0;
  document.addEventListener(
    "mousemove",
    (e) => {
      const now = performance.now();
      if (now - lastMove < 50) return; // plenty, and keeps it light
      lastMove = now;
      if (e.target === pill || pill.contains(e.target)) {
        clearTimeout(hideTimer);
        clearTimeout(idleTimer);
        pill.classList.remove("idle");
        return;
      }
      const video = videoUnder(e.clientX, e.clientY);
      if (video) show(video);
      else if (current) hideSoon();
    },
    true,
  );
  document.addEventListener("mouseleave", () => current && hideSoon());

  pill.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!current) return;
    pill.classList.add("busy");
    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: "yoinky-send", url: videoUrl(current), source: "video" });
    } catch {
      result = { ok: false, error: "Reload this page to use Yoinky (the extension was updated)." };
    }
    pill.classList.remove("busy");
    toast(result?.ok ? "Sent to Yoinky. Pick the quality there." : result?.error || "Couldn't reach Yoinky.", !result?.ok);
  });
  // Don't let the player treat the click as play/pause.
  for (const type of ["mousedown", "mouseup", "dblclick", "pointerdown", "pointerup"]) {
    pill.addEventListener(type, (e) => e.stopPropagation());
  }

  function toast(text, isError) {
    const t = document.createElement("div");
    t.className = `yoinky-toast${isError ? " error" : ""}`;
    t.textContent = text;
    host().appendChild(t);
    requestAnimationFrame(() => t.classList.add("on"));
    setTimeout(() => {
      t.classList.remove("on");
      setTimeout(() => t.remove(), 300);
    }, 3200);
  }
})();
