// Yoinky: a small "Download" button on videos, and the description of the
// last right-clicked image (used to give the downloaded file a good name).
(() => {
  if (window.__yoinky) return;
  window.__yoinky = true;

  // ---- Image descriptions for the right-click menu
  let lastDescription = "";
  // On Google Images, the thumbnail sits inside a result link that carries the
  // original's address; sending that gets the full-size picture.
  let lastResultLink = "";
  document.addEventListener(
    "contextmenu",
    (e) => {
      const img = e.target instanceof Element ? e.target.closest("img") : null;
      lastDescription = img ? (img.getAttribute("alt") || img.getAttribute("title") || "").trim() : "";
      lastResultLink = "";
      const link = img?.closest("a[href]");
      const href = link?.getAttribute("href") || "";
      if (href && /\/imgres\?|[?&]imgurl=|[?&]imgrc=/.test(href)) {
        try {
          lastResultLink = new URL(href, location.href).href;
        } catch {}
      } else if (/(^|\.)google\./.test(location.hostname) && img) {
        // Opened big (the side panel): the big image is the original itself,
        // unless it's still a gstatic preview.
        const src = img.currentSrc || img.src || "";
        if (/^https?:/.test(src) && !/gstatic\.com/.test(src)) lastResultLink = src;
      }
    },
    true,
  );
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg?.type === "yoinky-last-description") reply({ description: lastDescription, resultLink: lastResultLink });
  });

  // ---- Video button
  // Not on copy-protected (DRM) streaming services: Yoinky can't download those.
  const DRM_HOSTS = /(^|\.)(netflix\.com|disneyplus\.com|primevideo\.com|hulu\.com|max\.com|hbomax\.com|tv\.apple\.com|peacocktv\.com|paramountplus\.com|crave\.ca|crunchyroll\.com|spotify\.com|music\.apple\.com|tidal\.com|deezer\.com)$/i;
  const isAmazonVideo = /(^|\.)amazon\./i.test(location.hostname) && /\/(gp\/)?video\//.test(location.pathname);
  if (DRM_HOSTS.test(location.hostname) || isAmazonVideo) return;

  const pill = document.createElement("button");
  pill.className = "yoinky-pill";
  pill.type = "button";
  pill.innerHTML =
    '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg><span>Yoinky</span>';
  pill.title = "Download this video with Yoinky";
  let current = null;
  let hideTimer = 0;

  function videoUrl(video) {
    const src = video.currentSrc || video.src || "";
    // Streamed videos (blob:, HLS, DASH) are downloaded from their page instead.
    if (/^https?:/i.test(src) && !/\.(m3u8|mpd)(\?|$)/i.test(src) && !/youtube\.com|googlevideo\.com/.test(src)) return src;
    return location.href;
  }

  function place(video) {
    const r = video.getBoundingClientRect();
    pill.style.top = `${Math.max(8, r.top + 10)}px`;
    pill.style.left = `${Math.min(window.innerWidth - 110, r.right - 102)}px`;
  }

  function show(video) {
    clearTimeout(hideTimer);
    current = video;
    if (!pill.isConnected) document.documentElement.appendChild(pill);
    place(video);
    pill.classList.add("on");
  }

  function hideSoon() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      pill.classList.remove("on");
      current = null;
    }, 600);
  }

  document.addEventListener(
    "mouseover",
    (e) => {
      if (e.target === pill || pill.contains(e.target)) {
        clearTimeout(hideTimer);
        return;
      }
      // The hovered element may be a video, or a player overlay above one.
      const video = videoUnder(e.clientX, e.clientY);
      if (video) show(video);
      else if (current) hideSoon();
    },
    true,
  );
  window.addEventListener("scroll", () => current && place(current), true);

  function videoUnder(x, y) {
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < 280 || r.height < 150) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return v;
    }
    return null;
  }

  pill.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!current) return;
    pill.classList.add("busy");
    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: "yoinky-send", url: videoUrl(current), source: "video" });
    } catch {
      result = { ok: false, error: "Reload this page to use Yoinky (the extension was updated)." };
    }
    pill.classList.remove("busy");
    toast(result?.ok ? "Sent to Yoinky. Pick the quality there." : result?.error || "Couldn't reach Yoinky.", !result?.ok);
  });

  function toast(text, isError) {
    const t = document.createElement("div");
    t.className = `yoinky-toast${isError ? " error" : ""}`;
    t.textContent = text;
    document.documentElement.appendChild(t);
    requestAnimationFrame(() => t.classList.add("on"));
    setTimeout(() => {
      t.classList.remove("on");
      setTimeout(() => t.remove(), 300);
    }, 3200);
  }
})();
